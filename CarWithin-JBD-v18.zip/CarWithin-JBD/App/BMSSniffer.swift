import CoreBluetooth
import Foundation

/// 协议抓包：连接保护板，订阅全部通知通道，先静默观察，再依次发一批
/// 候选请求帧（旧 DD 帧 + 新 FF 鉴权帧），把每个字节都记下来用于离线解析。
/// 只读，不写参数类命令。
final class BMSSniffer: NSObject, CBCentralManagerDelegate, CBPeripheralDelegate {
    private(set) var lines: [String] = []
    private(set) var status = "未开始"
    /// 板子若暴露标准电量服务（0x180F/0x2A19），这里就是实时电量百分比。
    private(set) var level: Int?
    var onChange: (() -> Void)?

    private var central: CBCentralManager?
    private var target: CBPeripheral?
    private var discovered: [UUID: CBPeripheral] = [:]
    private var writable: [CBCharacteristic] = []
    private var notifiable: [CBCharacteristic] = []
    private var probes: [(String, Data)] = []
    private var probeIndex = 0
    private var probeTimer: Timer?
    private var quietTimer: Timer?
    private var batteryCharacteristic: CBCharacteristic?
    private var didWrite = false
    private var writePending = false

    /// 静默观察时长，先判断板子会不会主动推数据。
    private let quietSeconds: TimeInterval = 20
    private static let batteryLevelCharacteristic = CBUUID(string: "2A19")

    func start() {
        guard central == nil else { return }
        central = CBCentralManager(delegate: self, queue: .main)
    }

    func stop() {
        probeTimer?.invalidate(); probeTimer = nil
        quietTimer?.invalidate(); quietTimer = nil
        central?.stopScan()
        if let target, target.state != .disconnected { central?.cancelPeripheralConnection(target) }
        target = nil
        central = nil
        status = "已停止"
        onChange?()
    }

    func text() -> String { lines.joined(separator: "\n") }

    private func log(_ text: String) {
        let formatter = Self.formatter
        lines.append("[" + formatter.string(from: Date()) + "] " + text)
        if lines.count > 4000 { lines.removeFirst(lines.count - 4000) }
        onChange?()
    }

    private static let formatter: DateFormatter = {
        let f = DateFormatter()
        f.dateFormat = "HH:mm:ss.SSS"
        return f
    }()

    private func update(_ text: String) {
        status = text
        log("## " + text)
    }

    // MARK: - 蓝牙

    func centralManagerDidUpdateState(_ central: CBCentralManager) {
        guard central.state == .poweredOn else {
            update("蓝牙不可用（\(central.state.rawValue)）")
            return
        }
        if let text = UserDefaults.standard.string(forKey: "jbdBMSPeripheral"),
           let id = UUID(uuidString: text),
           let known = central.retrievePeripherals(withIdentifiers: [id]).first {
            log("使用已记住的设备 \(known.name ?? "未命名")")
            connect(known)
            return
        }
        update("扫描中…最多 8 秒")
        central.scanForPeripherals(withServices: nil, options: nil)
        DispatchQueue.main.asyncAfter(deadline: .now() + 8) { [weak self] in
            guard let self, self.target == nil else { return }
            self.central?.stopScan()
            guard let any = self.discovered.values.first else {
                self.update("没有扫到设备，请先在「连接设备」里选定保护板")
                return
            }
            self.connect(any)
        }
    }

    private func connect(_ peripheral: CBPeripheral) {
        central?.stopScan()
        target = peripheral
        peripheral.delegate = self
        update("正在连接 \(peripheral.name ?? "未命名")…")
        central?.connect(peripheral, options: nil)
    }

    func centralManager(_ central: CBCentralManager, didDiscover peripheral: CBPeripheral,
                        advertisementData: [String: Any], rssi RSSI: NSNumber) {
        discovered[peripheral.identifier] = peripheral
        let name = advertisementData[CBAdvertisementDataLocalNameKey] as? String ?? peripheral.name ?? "未命名"
        log("发现 \(name) \(RSSI)dBm")
    }

    func centralManager(_ central: CBCentralManager, didConnect peripheral: CBPeripheral) {
        update("已连接，发现全部服务")
        peripheral.discoverServices(nil)
    }

    func centralManager(_ central: CBCentralManager, didFailToConnect peripheral: CBPeripheral, error: Error?) {
        update("连接失败：\(error?.localizedDescription ?? "-")")
    }

    func centralManager(_ central: CBCentralManager, didDisconnectPeripheral peripheral: CBPeripheral, error: Error?) {
        update("已断开")
        writable.removeAll(); notifiable.removeAll()
    }

    func peripheral(_ peripheral: CBPeripheral, didDiscoverServices error: Error?) {
        guard let services = peripheral.services else { return }
        for service in services {
            log("服务 \(service.uuid)")
            peripheral.discoverCharacteristics(nil, for: service)
        }
    }

    func peripheral(_ peripheral: CBPeripheral, didDiscoverCharacteristicsFor service: CBService, error: Error?) {
        for characteristic in service.characteristics ?? [] {
            let props = Self.describe(characteristic.properties)
            log("特征 \(characteristic.uuid) [\(props)]")
            if characteristic.properties.contains(.notify) || characteristic.properties.contains(.indicate) {
                if !notifiable.contains(where: { $0.uuid == characteristic.uuid }) {
                    notifiable.append(characteristic)
                    peripheral.setNotifyValue(true, for: characteristic)
                }
            }
            if characteristic.uuid == Self.batteryLevelCharacteristic {
                batteryCharacteristic = characteristic
                peripheral.readValue(for: characteristic)
                if characteristic.properties.contains(.notify) || characteristic.properties.contains(.indicate) {
                    peripheral.setNotifyValue(true, for: characteristic)
                }
                log("发现标准电量特征 0x2A19，已读取")
            }
            if characteristic.properties.contains(.write) || characteristic.properties.contains(.writeWithoutResponse) {
                if !writable.contains(where: { $0.uuid == characteristic.uuid }) {
                    writable.append(characteristic)
                }
            }
        }
        if target === peripheral, !notifiable.isEmpty, !writable.isEmpty, probes.isEmpty {
            beginQuietPhase()
        }
    }

    func peripheral(_ peripheral: CBPeripheral, didUpdateNotificationStateFor characteristic: CBCharacteristic, error: Error?) {
        if let error {
            log("订阅 \(characteristic.uuid) 失败：\(error.localizedDescription)")
            return
        }
        log("已订阅 \(characteristic.uuid)")
    }

    func peripheral(_ peripheral: CBPeripheral, didUpdateValueFor characteristic: CBCharacteristic, error: Error?) {
        guard let data = characteristic.value, !data.isEmpty else { return }
        log("← \(characteristic.uuid.uuidString.prefix(8)) \(data.count)B  \(Self.hex(data))")
        if characteristic.uuid == Self.batteryLevelCharacteristic, let first = data.first {
            level = Int(first)
            log("电量 \(first)%")
            onChange?()
        }
    }

    func peripheral(_ peripheral: CBPeripheral, didWriteValueFor characteristic: CBCharacteristic, error: Error?) {
        writePending = false
        if let error { log("写 \(characteristic.uuid) 失败：\(error.localizedDescription)") }
    }

    // MARK: - 两个阶段

    private func beginQuietPhase() {
        update("阶段一：静默订阅 \(Int(quietSeconds)) 秒，观察板子是否主动推数据")
        quietTimer?.invalidate()
        let timer = Timer(timeInterval: quietSeconds, repeats: false) { [weak self] _ in
            self?.beginProbePhase()
        }
        quietTimer = timer
        RunLoop.main.add(timer, forMode: .common)
    }

    private func beginProbePhase() {
        probes = Self.makeProbes()
        probeIndex = 0
        update("阶段二：依次发送 \(probes.count) 种候选帧，每种等 2 秒")
        let timer = Timer(timeInterval: 2, repeats: true) { [weak self] _ in
            self?.fireNextProbe()
        }
        probeTimer = timer
        RunLoop.main.add(timer, forMode: .common)
        fireNextProbe()
    }

    private func fireNextProbe() {
        guard probeIndex < probes.count else {
            probeTimer?.invalidate(); probeTimer = nil
            update("探测完成，请导出日志")
            return
        }
        let (label, frame) = probes[probeIndex]
        probeIndex += 1
        update("探测 \(probeIndex)/\(probes.count)：\(label)")
        // 同一条帧发给所有可写通道，避免通道猜错。
        for characteristic in writable {
            let type: CBCharacteristicWriteType = characteristic.properties.contains(.write) ? .withResponse : .withoutResponse
            if type == .withoutResponse, let peripheral = target, !peripheral.canSendWriteWithoutResponse { continue }
            log("→ \(characteristic.uuid.uuidString.prefix(8)) \(Self.hex(frame))")
            target?.writeValue(frame, for: characteristic, type: type)
        }
    }

    // MARK: - 候选帧

    private static func makeProbes() -> [(String, Data)] {
        var list: [(String, Data)] = [
            ("旧协议 读基本信息", Data([0xDD, 0xA5, 0x03, 0x00, 0xFF, 0xFD, 0x77])),
            ("旧协议 读单体电压", Data([0xDD, 0xA5, 0x04, 0x00, 0xFF, 0xFC, 0x77])),
            ("新协议 AppKey 000000", ffFrame(0x15, Data("000000".utf8))),
            ("新协议 取随机数", ffFrame(0x17, Data())),
            ("新协议 状态 0x24", ffFrame(0x24, Data())),
            ("新协议 读 0x03", ffFrame(0x03, Data())),
            ("新协议 读 0x04", ffFrame(0x04, Data())),
            ("新协议 读 0x01", ffFrame(0x01, Data()))
        ]
        list.append(("唤醒 FF AA 00 00", Data([0xFF, 0xAA, 0x00, 0x00, 0x00])))
        return list
    }

    /// 新协议帧：FF AA + 命令 + 长度 + 数据 + 8 位累加校验（命令+长度+数据）。
    private static func ffFrame(_ command: UInt8, _ payload: Data) -> Data {
        var frame = Data([0xFF, 0xAA, command, UInt8(payload.count)])
        frame.append(payload)
        var checksum: UInt8 = 0
        for byte in frame.dropFirst(2) { checksum = checksum &+ byte }
        frame.append(checksum)
        return frame
    }

    private static func hex(_ data: Data) -> String {
        data.map { String(format: "%02X", $0) }.joined(separator: " ")
    }

    private static func describe(_ properties: CBCharacteristicProperties) -> String {
        var parts: [String] = []
        if properties.contains(.read) { parts.append("R") }
        if properties.contains(.write) { parts.append("W") }
        if properties.contains(.writeWithoutResponse) { parts.append("WNR") }
        if properties.contains(.notify) { parts.append("N") }
        if properties.contains(.indicate) { parts.append("I") }
        return parts.joined(separator: ",")
    }
}
