import UIKit

/// A schematic background, using the same bitmap and scale as the real video.
/// Example readings stay in this settings view and never enter live telemetry.
final class BMSCardPreviewView: UIView, UIGestureRecognizerDelegate {
    var configuration = BMSCardConfiguration() { didSet { setNeedsDisplay() } }
    /// Drag moves the bar freely; the lock switch turns this off.
    var isDragEnabled = true
    var onDrag: ((Double, Double) -> Void)?
    var image: CGImage? { didSet { setNeedsDisplay() } }
    var videoAspectRatio: CGFloat = 848 / 480 {
        didSet {
            guard videoAspectRatio != oldValue else { return }
            aspectConstraint?.isActive = false
            aspectConstraint = heightAnchor.constraint(equalTo: widthAnchor, multiplier: 1 / max(1, videoAspectRatio))
            aspectConstraint?.isActive = true
        }
    }
    private var aspectConstraint: NSLayoutConstraint?
    private var panGesture: UIPanGestureRecognizer?
    private weak var hostScrollView: UIScrollView?
    private var waitsForHostScroll = false
    private var renderedText: [String]?
    private var renderedConfiguration: BMSCardConfiguration?

    func update(reading: BMSReading?, configuration: BMSCardConfiguration, aspectRatio: CGFloat) {
        if self.configuration != configuration { self.configuration = configuration }
        videoAspectRatio = aspectRatio
        let previewReading = reading ?? Self.example
        let text = configuration.lines(for: previewReading)
        if renderedText != text || renderedConfiguration != configuration {
            renderedText = text; renderedConfiguration = configuration
            image = BMSOverlayPresenter.preview(previewReading, configuration: configuration)
        }
        accessibilityValue = (reading == nil ? "示例数据，非实时读数。" : "实时数据。")
            + configuration.position.title + "，" + text.joined(separator: "，")
    }

    /// 23 cells so the preview shows the same grid the instrument draws.
    static let example = BMSReading(voltage: 75.4, current: 0, power: 0, stateOfCharge: 42,
        stateOfHealth: nil, stateCode: 1, capacityAh: 50, remainingAh: 20.8,
        cells: [3.277, 3.279, 3.281, 3.276, 3.280, 3.278, 3.279, 3.277, 3.282, 3.276, 3.279, 3.278,
                3.280, 3.277, 3.281, 3.279, 3.278, 3.276, 3.280, 3.279, 3.277, 3.281, 3.278],
        temperatures: [16], mosTemperature: 16, protectionBits: 0, warningBits: 0)

    override init(frame: CGRect) {
        super.init(frame: frame)
        isOpaque = false; isAccessibilityElement = true; accessibilityLabel = "BMS 卡片布局预览"
        layer.cornerRadius = 12; clipsToBounds = true
        aspectConstraint = heightAnchor.constraint(equalTo: widthAnchor, multiplier: 480 / 848)
        aspectConstraint?.isActive = true
        let pan = UIPanGestureRecognizer(target: self, action: #selector(handlePan(_:)))
        pan.delegate = self
        panGesture = pan
        addGestureRecognizer(pan)
    }
    required init?(coder: NSCoder) { fatalError("init(coder:) is not supported") }

    override func didMoveToWindow() {
        super.didMoveToWindow()
        // The preview lives inside the settings table, whose own pan would
        // otherwise swallow the drag before it starts.
        var view: UIView? = superview
        while let candidate = view {
            if let scroll = candidate as? UIScrollView { hostScrollView = scroll; break }
            view = candidate.superview
        }
        guard let scroll = hostScrollView, let pan = panGesture, !waitsForHostScroll else { return }
        scroll.panGestureRecognizer.require(toFail: pan)
        waitsForHostScroll = true
    }

    func gestureRecognizer(_ gestureRecognizer: UIGestureRecognizer, shouldReceive touch: UITouch) -> Bool {
        // Touches anywhere else in the table must scroll as usual.
        let point = touch.location(in: self)
        return bounds.contains(point)
    }

    @objc private func handlePan(_ gesture: UIPanGestureRecognizer) {
        guard isDragEnabled, bounds.width > 0, bounds.height > 0 else { return }
        if gesture.state == .began { hostScrollView?.isScrollEnabled = false }
        if gesture.state == .ended || gesture.state == .cancelled || gesture.state == .failed {
            hostScrollView?.isScrollEnabled = true
        }
        let point = gesture.location(in: self)
        onDrag?(Double(min(1, max(0, point.x / bounds.width))),
                Double(min(1, max(0, point.y / bounds.height))))
    }

    override func draw(_ rect: CGRect) {
        UIColor.secondarySystemBackground.setFill(); UIRectFill(bounds)
        let roads = UIBezierPath()
        for x in stride(from: CGFloat(24), to: bounds.width, by: 54) {
            roads.move(to: CGPoint(x: x, y: 0)); roads.addLine(to: CGPoint(x: x + 24, y: bounds.height))
        }
        for y in stride(from: CGFloat(22), to: bounds.height, by: 42) {
            roads.move(to: CGPoint(x: 0, y: y)); roads.addLine(to: CGPoint(x: bounds.width, y: y + 12))
        }
        UIColor.separator.withAlphaComponent(0.45).setStroke(); roads.lineWidth = 7; roads.stroke()
        let route = UIBezierPath()
        route.move(to: CGPoint(x: bounds.width * 0.3, y: bounds.height))
        route.addLine(to: CGPoint(x: bounds.width * 0.4, y: bounds.height * 0.52))
        route.addLine(to: CGPoint(x: bounds.width * 0.63, y: bounds.height * 0.52))
        route.addLine(to: CGPoint(x: bounds.width * 0.68, y: 0))
        UIColor.systemBlue.withAlphaComponent(0.7).setStroke(); route.lineWidth = 5; route.lineJoinStyle = .round; route.stroke()
        guard let image else { return }
        if configuration.layout == .panel {
            // Full-height strip pinned to the right edge, exactly how the
            // instrument video composites it.
            let width = bounds.width * CGFloat(configuration.panelWidthFraction)
            UIImage(cgImage: image).draw(in: CGRect(x: bounds.width - width, y: 0,
                                                   width: width, height: bounds.height))
            return
        }
        let inset = configuration.layout == .panel ? CGFloat(configuration.leftInsetFraction) : 0
        let widthFraction: Double = configuration.layout == .panel
            ? configuration.panelWidthFraction * (1 - Double(inset)) : configuration.size.widthFraction
        let width = bounds.width * CGFloat(widthFraction)
        let height = width * CGFloat(image.height) / CGFloat(image.width)
        let halfFraction = CGFloat(widthFraction) / 2
        let anchorX = min(max(CGFloat(configuration.anchorX), inset + halfFraction),
                          1 - halfFraction)
        let centreX = bounds.width * anchorX
        let centreY = bounds.height * CGFloat(min(1, max(0, configuration.anchorY)))
        let x = min(max(0, centreX - width / 2), max(0, bounds.width - width))
        let y = min(max(0, centreY - height / 2), max(0, bounds.height - height))
        UIImage(cgImage: image).draw(in: CGRect(x: x, y: y, width: width, height: height))
    }
}
