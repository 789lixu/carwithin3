import CoreImage
import UIKit

/// Renders a small, noninteractive telemetry panel once per changed text. The
/// same bitmap is shown locally and composited into Ninebot's encoded video.
final class BMSOverlayPresenter {
    private let imageView = UIImageView()
    private var cachedText: String?
    private var cachedImage: CGImage?
    private var cachedConfiguration: BMSCardConfiguration?
    private var constraints: [NSLayoutConstraint] = []
    private var anchorGuide: UILayoutGuide?
    private var animationTimer: Timer?
    private var phase: Double = 0
    private var currentReading: BMSReading?
    private var currentConfiguration = BMSCardConfiguration()
    private var enabledNow = false
    var onImage: ((CGImage?, BMSCardConfiguration) -> Void)?

    func attach(to surface: UIView) {
        imageView.isUserInteractionEnabled = false
        imageView.isAccessibilityElement = true
        imageView.accessibilityLabel = "电池实时信息"
        imageView.contentMode = .scaleAspectFit
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.isHidden = true
        surface.addSubview(imageView)
        cachedConfiguration = nil // Layout must be rebuilt even if telemetry arrived before attachment.
    }

    func update(enabled: Bool, reading: BMSReading?, status: String,
                configuration: BMSCardConfiguration) {
        enabledNow = enabled
        currentReading = reading
        currentConfiguration = configuration
        defer { syncAnimation() }
        guard enabled else {
            let wasVisible = !imageView.isHidden
            imageView.isHidden = true
            cachedText = nil; cachedImage = nil; cachedConfiguration = nil
            if wasVisible { onImage?(nil, configuration) }
            return
        }
        let text: String
        if let reading {
            text = configuration.lines(for: reading).joined(separator: "\n")
        } else {
            text = "JBD BMS · 无实时数据\n" + (status.contains("过期") || status.contains("断开") || status.contains("重连")
                ? "连接失联，等待恢复" : "等待电池数据")
        }
        let previousLineCount = cachedText?.components(separatedBy: "\n").count
        let lineCount = min(2, text.components(separatedBy: "\n").count)
        let styleChanged = cachedConfiguration?.backgroundOpacity != configuration.backgroundOpacity
            || cachedConfiguration?.textColorHex != configuration.textColorHex
            || cachedConfiguration?.layout != configuration.layout
            || cachedConfiguration?.barColorHex != configuration.barColorHex
            || cachedConfiguration?.barTrackColorHex != configuration.barTrackColorHex
            || cachedConfiguration?.dataColorHex != configuration.dataColorHex
            || cachedConfiguration?.wallpaperEnabled != configuration.wallpaperEnabled
        let changed = text != cachedText || cachedConfiguration != configuration || imageView.isHidden
        let needsLayout = previousLineCount != lineCount || cachedConfiguration != configuration
        if text != cachedText || styleChanged {
            cachedImage = configuration.layout == .panel
                ? BMSPanelRenderer.render(reading, configuration: configuration, phase: phase)
                : Self.render(text, alarm: reading?.hasAlarm == true,
                              opacity: configuration.backgroundOpacity,
                              textColor: BMSThemeColor.color(hex: configuration.textColorHex))
            imageView.image = cachedImage.map { UIImage(cgImage: $0) }
            imageView.accessibilityValue = text.replacingOccurrences(of: "\n", with: "，")
        }
        cachedText = text; cachedConfiguration = configuration
        imageView.isHidden = false
        if let surface = imageView.superview, needsLayout {
            layout(on: surface, configuration: configuration, lineCount: lineCount)
        }
        if changed { onImage?(cachedImage, configuration) }
    }

    /// Used by settings only. A sample reading must never enter the live overlay.
    static func preview(_ reading: BMSReading, configuration: BMSCardConfiguration) -> CGImage? {
        if configuration.layout == .panel {
            return BMSPanelRenderer.render(reading, configuration: configuration, phase: 0.68)
        }
        return render(configuration.lines(for: reading).joined(separator: "\n"),
               alarm: reading.hasAlarm, opacity: configuration.backgroundOpacity,
               textColor: BMSThemeColor.color(hex: configuration.textColorHex))
    }

    /// A slow redraw loop keeps the charging dot moving. It only runs while the
    /// panel is visible and the pack is actually charging, so an idle bike costs
    /// nothing.
    private func syncAnimation() {
        let wanted = enabledNow && !imageView.isHidden
            && currentConfiguration.shouldAnimateCharging(currentReading)
        if wanted, animationTimer == nil {
            let timer = Timer(timeInterval: 0.11, repeats: true) { [weak self] _ in
                self?.advanceAnimation()
            }
            animationTimer = timer
            RunLoop.main.add(timer, forMode: .common)
        } else if !wanted {
            animationTimer?.invalidate(); animationTimer = nil
            if phase != 0 { phase = 0 }
        }
    }

    private func advanceAnimation() {
        guard enabledNow, !imageView.isHidden, currentConfiguration.layout == .panel else {
            syncAnimation(); return
        }
        phase += 0.034
        if phase >= 1 { phase -= 1 }
        if let image = BMSPanelRenderer.render(currentReading, configuration: currentConfiguration,
                                               phase: phase) {
            imageView.image = UIImage(cgImage: image)
            onImage?(image, currentConfiguration)
        }
    }

    private func layout(on surface: UIView, configuration: BMSCardConfiguration, lineCount: Int) {
        NSLayoutConstraint.deactivate(constraints)
        if configuration.layout == .panel {
            // The panel is a full-height strip pinned to the right edge of the
            // video: the vehicle's P card sits inside it and our drawings avoid
            // that band, so nothing can be hidden behind the P overlay.
            imageView.contentMode = .scaleToFill
            if let guide = anchorGuide { surface.removeLayoutGuide(guide); anchorGuide = nil }
            constraints = [
                imageView.trailingAnchor.constraint(equalTo: surface.trailingAnchor),
                imageView.topAnchor.constraint(equalTo: surface.topAnchor),
                imageView.bottomAnchor.constraint(equalTo: surface.bottomAnchor),
                imageView.widthAnchor.constraint(equalTo: surface.widthAnchor,
                    multiplier: CGFloat(configuration.panelWidthFraction))
            ]
            NSLayoutConstraint.activate(constraints)
            return
        }
        imageView.contentMode = .scaleAspectFit
        // Free placement: the bar centre sits on a fraction of the video size.
        // A layout guide is used instead of a multiplier on .trailing, because
        // multipliers on position attributes are measured in the common
        // ancestor's coordinates and drift when the video view is inset.
        if let guide = anchorGuide { surface.removeLayoutGuide(guide) }
        let guide = UILayoutGuide()
        surface.addLayoutGuide(guide)
        anchorGuide = guide
        let inset = configuration.layout == .panel ? configuration.leftInsetFraction : 0
        let widthFraction = configuration.layout == .panel
            ? configuration.panelWidthFraction * (1 - inset) : configuration.size.widthFraction
        let clampedX = min(max(configuration.anchorX, inset + widthFraction / 2),
                           1 - widthFraction / 2)
        constraints = [
            guide.leadingAnchor.constraint(equalTo: surface.leadingAnchor),
            guide.topAnchor.constraint(equalTo: surface.topAnchor),
            guide.widthAnchor.constraint(equalTo: surface.widthAnchor,
                multiplier: CGFloat(clampedX), constant: 0),
            guide.heightAnchor.constraint(equalTo: surface.heightAnchor,
                multiplier: CGFloat(min(1, max(0, configuration.anchorY))), constant: 0),
            imageView.widthAnchor.constraint(equalTo: surface.widthAnchor,
                multiplier: CGFloat(widthFraction)),
            imageView.heightAnchor.constraint(equalTo: imageView.widthAnchor,
                multiplier: configuration.layout == .panel
                    ? BMSPanelRenderer.aspect
                    : CGFloat(lineCount == 1 ? 72 : 122) / 640),
            imageView.centerXAnchor.constraint(equalTo: guide.trailingAnchor),
            imageView.centerYAnchor.constraint(equalTo: guide.bottomAnchor)
        ]
        NSLayoutConstraint.activate(constraints)
    }

    private static func render(_ text: String, alarm: Bool, opacity: Double, textColor: UIColor) -> CGImage? {
        let lineCount = min(2, text.components(separatedBy: "\n").count)
        let size = CGSize(width: 640, height: lineCount == 1 ? 72 : 122)
        let format = UIGraphicsImageRendererFormat()
        format.scale = 1
        return UIGraphicsImageRenderer(size: size, format: format).image { _ in
            UIColor.black.withAlphaComponent(min(1, max(0, opacity))).setFill()
            UIBezierPath(roundedRect: CGRect(origin: .zero, size: size), cornerRadius: 16).fill()
            let paragraph = NSMutableParagraphStyle()
            paragraph.lineBreakMode = .byTruncatingTail
            let color: UIColor = alarm ? .systemOrange : textColor
            for (index, line) in text.components(separatedBy: "\n").prefix(2).enumerated() {
                let baseFont = UIFont.monospacedDigitSystemFont(ofSize: 36, weight: .semibold)
                let width = (line as NSString).size(withAttributes: [.font: baseFont]).width
                let font = UIFont.monospacedDigitSystemFont(ofSize: min(36, max(14, 36 * 604 / max(1, width))), weight: .semibold)
                (line as NSString).draw(in: CGRect(x: 18, y: CGFloat(12 + index * 50), width: 604, height: 48), withAttributes: [
                    .font: font, .foregroundColor: color, .paragraphStyle: paragraph
                ])
            }
        }.cgImage
    }
}
