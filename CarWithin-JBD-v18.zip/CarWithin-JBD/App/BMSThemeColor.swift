import UIKit

/// Bar text colour helpers shared by the live overlay and the layout preview.
enum BMSThemeColor {
    /// "RRGGBB" (with or without '#') to UIColor; malformed values fall back to white.
    static func color(hex: String) -> UIColor {
        let cleaned = hex.replacingOccurrences(of: "#", with: "").uppercased()
        guard cleaned.count == 6, let value = UInt32(cleaned, radix: 16) else { return .white }
        return UIColor(red: CGFloat((value >> 16) & 0xFF) / 255,
                       green: CGFloat((value >> 8) & 0xFF) / 255,
                       blue: CGFloat(value & 0xFF) / 255,
                       alpha: 1)
    }

    static func hex(_ color: UIColor) -> String {
        var red: CGFloat = 1, green: CGFloat = 1, blue: CGFloat = 1, alpha: CGFloat = 1
        color.getRed(&red, green: &green, blue: &blue, alpha: &alpha)
        let clamp: (CGFloat) -> Int = { Int((min(1, max(0, $0)) * 255).rounded()) }
        return String(format: "%02X%02X%02X", clamp(red), clamp(green), clamp(blue))
    }
}

/// Keeps the system colour picker alive while it is presented and streams the choice back.
final class BMSColorPickerDelegate: NSObject, UIColorPickerViewControllerDelegate {
    var onPick: ((UIColor) -> Void)?

    func colorPickerViewControllerDidSelectColor(_ viewController: UIColorPickerViewController) {
        onPick?(viewController.selectedColor)
    }

    func colorPickerViewControllerDidFinish(_ viewController: UIColorPickerViewController) {
        onPick?(viewController.selectedColor)
    }
}
