import CoreBluetooth
import Foundation
import UIKit

/// Read-only 嘉佰达 (JBD) telemetry, confined to the main queue. A peripheral is
/// selected explicitly and remembered by CoreBluetooth UUID, never by strongest
/// signal. Each poll cycle asks for register 0x03 (basic telemetry) and then
/// register 0x04 (cell voltages); nothing is ever written to the protection board.
final class JBDBMSClient: NSObject, CBCentralManagerDelegate, CBPeripheralDelegate {
    struct Device {
        let id: UUID
        let name: String
        let rssi: Int
    }

    /// JBD modules expose FF00 with FF01 notifications and FF02 writes.
    private static let service = CBUUID(string: "FF00")
    private static let notifyCharacteristic = CBUUID(string: "FF01")
    private static let writeCharacteristic = CBUUID(string: "FF02")
    static let keySelectedID = "jbdBMSPeripheral"
    static let keySelectedName = "jbdBMSName"

    /// Preferences saved by the ANT build are adopted once so re-signing the app
    /// does not drop the user's device, card layout or enable switch.
    static func migrateLegacyDefaults(_ defaults: UserDefaults = .standard) {
        let pairs = ["antBMSPeripheral": keySelectedID, "antBMSName": keySelectedName,
                     "antBMSEnabled": "jbdBMSEnabled", "antBMSCardFields": "jbdBMSCardFields",
                     "antBMSCardSize": "jbdBMSCardSize", "antBMSPosition": "jbdBMSPosition",
                     "antBMSCardBackground": "jbdBMSCardBackground"]
        for (legacy, current) in pairs where defaults.object(forKey: current) == nil {
            guard let value = defaults.object(forKey: legacy) else { continue }
            defaults.set(value, forKey: current)
        }
    }

    private let defaults: UserDefaults
    private var central: CBCentralManager?
    private var peripheral: CBPeripheral?
    private var discovered: [UUID: CBPeripheral] = [:]
    private var found: [UUID: Device] = [:]
    private var writer: CBCharacteristic?
    private var reader: CBCharacteristic?
    private var parser = JBDBMSProtocol()
    private var assembler = JBDBMSAssembler()
    private var expectedCommand = JBDBMSAssembler.basicInfoCommand
    private var lastWriteAt: TimeInterval = 0
    private var lastFrameAt: TimeInterval?
    private var lastCycleAt: TimeInterval = 0
    private var timer: Timer?
    private var reconnectWork: DispatchWorkItem?
    private var scanTimeout: DispatchWorkItem?
    private var enabled = false
    private var scanRequested = false
    private var writePending = false
    private var connectedAt: TimeInterval?
    private var retryDelay: TimeInterval = 1
    private var disconnecting = Set<UUID>()
    /// Seconds between complete 0x03+0x04 read cycles. Longer means fewer
    /// packets, which buys range on a weak BLE link at the cost of refresh rate.
    var pollInterval: TimeInterval = 1 { didSet { onChange?() } }
    /// Last values stay on screen through a short drop instead of blinking to "--".
    var freshnessWindow: TimeInterval { max(10, pollInterval * 3) }
    /// Extra spacing added after a drop, so a marginal link gets fewer packets
    /// instead of hammering the air until it fails again.
    private var penalty: TimeInterval = 0
    private var lastDropAt: TimeInterval = 0
    /// 连续失败次数，用于 1→2→4→8 秒的退避重连（收到有效帧即清零）。
    private var failedAttempts = 0
    /// 链路已连接但收不到有效报文的起点，用来判断“会话僵死”。
    private var staleSince: TimeInterval?
    /// 软重置次数：连续软重置也救不回来时才真正断开重连。
    private var softResetCount = 0
    private var lastSoftResetAt: TimeInterval = 0
    private(set) var status = "未连接 BMS"
    private(set) var sample: BMSSample?
    var onChange: (() -> Void)?
    var onLog: ((String) -> Void)?

    var devices: [Device] { found.values.sorted { $0.rssi > $1.rssi } }
    var selectedID: UUID? { defaults.string(forKey: Self.keySelectedID).flatMap(UUID.init(uuidString:)) }
    var selectedName: String { defaults.string(forKey: Self.keySelectedName) ?? "未选择" }
    var freshReading: BMSReading? {
        guard let sample,
              sample.isFresh(at: ProcessInfo.processInfo.systemUptime, maximumAge: freshnessWindow)
        else { return nil }
        return sample.reading
    }
    /// Last decoded values, even if the link just dropped. Used only to keep the
    /// instrument from blinking "--" for a couple of seconds during a reconnect.
    var lastReading: BMSReading? { sample?.reading }

    init(defaults: UserDefaults = .standard) {
        self.defaults = defaults
        super.init()
        Self.migrateLegacyDefaults(defaults)
    }

    deinit {
        timer?.invalidate(); reconnectWork?.cancel(); scanTimeout?.cancel()
    }

    func start() {
        guard !enabled else { return }
        enabled = true
        if central == nil {
            central = CBCentralManager(delegate: self, queue: .main)
        } else if central?.state == .poweredOn {
            connectRememberedOrScan()
        } else {
            update("等待蓝牙可用")
        }
        let timer = Timer(timeInterval: 1, repeats: true) { [weak self] _ in self?.tick() }
        self.timer = timer
        RunLoop.main.add(timer, forMode: .common)
    }

    func stop() {
        enabled = false; scanRequested = false
        timer?.invalidate(); timer = nil
        reconnectWork?.cancel(); reconnectWork = nil
        scanTimeout?.cancel(); scanTimeout = nil
        central?.stopScan()
        clearConnection()
        update("未连接 BMS")
    }

    func scan() {
        guard enabled else { return }
        scanRequested = true
        found.removeAll(); discovered.removeAll()
        beginScan()
    }

    /// Experimental MOS control, sent only when the caller has confirmed the
    /// pack is idle. The board itself refuses to cut discharge under load.
    @discardableResult
    func requestDischarge(_ enabled: Bool) -> Bool {
        guard let peripheral = self.peripheral, let writer = self.writer,
              peripheral.state == .connected else { return false }
        // 0xE1 keeps the documented JBD MOS semantics: bit0 charge, bit1 discharge.
        let mode: UInt8 = enabled ? 0x03 : 0x01
        var bytes: [UInt8] = [0xdd, 0x5a, 0xe1, 0x01, mode]
        let sum = JBDBMSProtocol.checksum(bytes[2..<bytes.count])
        bytes.append(UInt8((sum >> 8) & 0xff))
        bytes.append(UInt8(sum & 0xff))
        bytes.append(0x77)
        let type: CBCharacteristicWriteType = writer.properties.contains(.writeWithoutResponse) ? .withoutResponse : .withResponse
        if type == .withoutResponse, !peripheral.canSendWriteWithoutResponse { return false }
        writePending = type == .withResponse
        lastWriteAt = ProcessInfo.processInfo.systemUptime
        peripheral.writeValue(Data(bytes), for: writer, type: type)
        onLog?("发送 MOS 控制：放电 " + (enabled ? "开" : "关"))
        return true
    }

    func select(_ id: UUID) {
        guard enabled, let device = found[id] else { return }
        defaults.set(id.uuidString, forKey: Self.keySelectedID)
        defaults.set(device.name, forKey: Self.keySelectedName)
        reconnectWork?.cancel(); reconnectWork = nil
        central?.stopScan(); scanRequested = false
        scanTimeout?.cancel(); scanTimeout = nil
        clearConnection()
        retryDelay = 1
        failedAttempts = 0; softResetCount = 0; staleSince = nil
        connectRememberedOrScan()
    }

    /// 手动触发一次恢复：连着蓝牙就软重置 GATT，断着就立刻重连。
    /// 设置页「立即恢复数据」按钮走这里，不用杀掉 App 再进页面。
    func forceReconnect() {
        guard enabled else { return }
        let now = ProcessInfo.processInfo.systemUptime
        if let peripheral, peripheral.state == .connected {
            softResetCount = 0
            lastSoftResetAt = 0
            staleSince = now - 5
            softReset(now: now)
        } else {
            failedAttempts = 0
            reconnectWork?.cancel(); reconnectWork = nil
            connectRememberedOrScan()
        }
    }

    /// App 回到前台时自动调用：iOS 在后台会悄悄让 BLE 订阅失效，
    /// 这里不用用户点任何按钮，直接把会话重建或立刻重连。
    func handleAppDidBecomeActive() {
        guard enabled, selectedID != nil else { return }
        let now = ProcessInfo.processInfo.systemUptime
        if let peripheral, peripheral.state == .connected {
            guard now - max(sample?.uptime ?? 0, connectedAt ?? 0) > 2 else { return }
            softResetCount = 0
            lastSoftResetAt = 0
            staleSince = now - 4
            softReset(now: now)
        } else {
            failedAttempts = 0
            reconnectWork?.cancel(); reconnectWork = nil
            connectRememberedOrScan()
        }
    }

    func forget() {
        clearConnection()
        reconnectWork?.cancel(); reconnectWork = nil
        defaults.removeObject(forKey: Self.keySelectedID)
        defaults.removeObject(forKey: Self.keySelectedName)
        if enabled { scan() } else { update("未选择 BMS") }
    }

    /// Restores a previously chosen device from a vehicle profile, never a scan guess.
    func restoreSelection(id: UUID?, name: String?) {
        clearConnection()
        reconnectWork?.cancel(); reconnectWork = nil
        if let id {
            defaults.set(id.uuidString, forKey: Self.keySelectedID)
            defaults.set(name ?? "JBD BMS", forKey: Self.keySelectedName)
        } else {
            defaults.removeObject(forKey: Self.keySelectedID)
            defaults.removeObject(forKey: Self.keySelectedName)
        }
        if enabled { connectRememberedOrScan() } else { update("已恢复车辆 BMS 配置") }
    }

    func centralManagerDidUpdateState(_ central: CBCentralManager) {
        if central.state != .poweredOn { disconnecting.removeAll() }
        guard enabled else { return }
        if central.state == .poweredOn {
            if scanRequested { beginScan() } else { connectRememberedOrScan() }
        } else {
            reconnectWork?.cancel(); reconnectWork = nil
            scanTimeout?.cancel(); scanTimeout = nil
            clearConnection()
            disconnecting.removeAll()
            switch central.state {
            case .unauthorized: update("蓝牙权限未允许，请在系统设置中开启")
            case .poweredOff: update("蓝牙已关闭")
            case .unsupported: update("此设备不支持 BMS 蓝牙读取")
            default: update("等待蓝牙可用")
            }
        }
    }

    private func connectRememberedOrScan() {
        guard enabled, let central, central.state == .poweredOn, peripheral == nil else { return }
        guard let id = selectedID else { scan(); return }
        guard !disconnecting.contains(id) else { scheduleReconnect(); return }
        if let target = discovered[id] ?? central.retrievePeripherals(withIdentifiers: [id]).first {
            central.stopScan()
            peripheral = target; target.delegate = self
            connectedAt = ProcessInfo.processInfo.systemUptime
            update("正在连接 \(selectedName)…")
            central.connect(target, options: nil)
        } else {
            scanRequested = true
            beginScan()
        }
    }

    private func beginScan() {
        guard enabled, let central, central.state == .poweredOn else { return }
        scanTimeout?.cancel()
        // Known JBD service filtering also supports iOS background discovery.
        central.scanForPeripherals(withServices: UIApplication.shared.applicationState == .active ? nil : [Self.service], options: nil)
        update("正在扫描嘉佰达 JBD BMS…")
        let timeout = DispatchWorkItem { [weak self] in
            guard let self, self.enabled else { return }
            self.central?.stopScan(); self.scanRequested = false
            if self.peripheral == nil {
                self.update(self.found.isEmpty ? "未找到嘉佰达 BMS，请确认保护板蓝牙已开启" : "请选择自己的嘉佰达 BMS")
                if self.selectedID != nil { self.scheduleReconnect() }
            }
        }
        scanTimeout = timeout
        DispatchQueue.main.asyncAfter(deadline: .now() + 15, execute: timeout)
    }

    func centralManager(_ central: CBCentralManager, didDiscover peripheral: CBPeripheral,
                        advertisementData: [String: Any], rssi RSSI: NSNumber) {
        guard enabled else { return }
        let name = advertisementData[CBAdvertisementDataLocalNameKey] as? String ?? peripheral.name ?? "未命名 FF00 设备"
        let services = advertisementData[CBAdvertisementDataServiceUUIDsKey] as? [CBUUID] ?? []
        guard name.uppercased().hasPrefix("JBD") || services.contains(Self.service)
                || peripheral.identifier == selectedID else { return }
        // Service FF00 is shared by many BLE boards; picking a candidate never
        // confirms JBD support. Only a checksum-valid 0x03 frame does that.
        discovered[peripheral.identifier] = peripheral
        found[peripheral.identifier] = Device(id: peripheral.identifier, name: name, rssi: RSSI.intValue)
        onChange?()
        if selectedID == peripheral.identifier, self.peripheral == nil { connectRememberedOrScan() }
    }

    func centralManager(_ central: CBCentralManager, didConnect peripheral: CBPeripheral) {
        guard enabled, peripheral === self.peripheral else { return }
        update("已连接蓝牙，正在发现 JBD 通道…")
        connectedAt = ProcessInfo.processInfo.systemUptime
        peripheral.discoverServices([Self.service])
    }

    func centralManager(_ central: CBCentralManager, didFailToConnect peripheral: CBPeripheral, error: Error?) {
        if disconnecting.remove(peripheral.identifier) != nil {
            if enabled, self.peripheral == nil { scheduleReconnect() }
            return
        }
        disconnected(peripheral, reason: "BMS 连接失败")
    }

    func centralManager(_ central: CBCentralManager, didDisconnectPeripheral peripheral: CBPeripheral, error: Error?) {
        if disconnecting.remove(peripheral.identifier) != nil {
            if enabled, self.peripheral == nil { scheduleReconnect() }
            return
        }
        disconnected(peripheral, reason: "BMS 已断开")
    }

    private func disconnected(_ device: CBPeripheral, reason: String) {
        guard device === peripheral else { return }
        registerDrop()
        clearConnection()
        guard enabled else { return }
        update(reason + "，等待重连")
        scheduleReconnect()
    }

    func peripheral(_ peripheral: CBPeripheral, didDiscoverServices error: Error?) {
        guard peripheral === self.peripheral, enabled else { return }
        guard error == nil, let service = peripheral.services?.first(where: { $0.uuid == Self.service }) else {
            failConnection("设备没有可用的 JBD FF00 服务"); return
        }
        peripheral.discoverCharacteristics(nil, for: service)
    }

    func peripheral(_ peripheral: CBPeripheral, didDiscoverCharacteristicsFor service: CBService, error: Error?) {
        guard peripheral === self.peripheral, enabled else { return }
        let candidates = service.characteristics ?? []
        func writable(_ characteristic: CBCharacteristic) -> Bool {
            characteristic.properties.contains(.write) || characteristic.properties.contains(.writeWithoutResponse)
        }
        func notifiable(_ characteristic: CBCharacteristic) -> Bool {
            characteristic.properties.contains(.notify) || characteristic.properties.contains(.indicate)
        }
        // Prefer the documented FF02 write / FF01 notify pair, but tolerate boards
        // that only expose one characteristic per direction.
        let writer = candidates.first { $0.uuid == Self.writeCharacteristic && writable($0) }
            ?? candidates.first { writable($0) }
        let reader = candidates.first { $0.uuid == Self.notifyCharacteristic && notifiable($0) }
            ?? candidates.first { notifiable($0) }
        guard error == nil, let writer, let reader else {
            failConnection("设备没有可用的 JBD FF01/FF02 收发通道"); return
        }
        self.writer = writer; self.reader = reader
        peripheral.setNotifyValue(true, for: reader)
        update("正在订阅 JBD 实时数据…")
    }

    func peripheral(_ peripheral: CBPeripheral, didUpdateNotificationStateFor characteristic: CBCharacteristic, error: Error?) {
        guard peripheral === self.peripheral, characteristic === reader, enabled else { return }
        guard error == nil, characteristic.isNotifying else { failConnection("BMS 通知订阅失败"); return }
        update("等待首个校验有效的 JBD 实时帧…")
        poll()
    }

    func peripheral(_ peripheral: CBPeripheral, didUpdateValueFor characteristic: CBCharacteristic, error: Error?) {
        guard peripheral === self.peripheral, characteristic === reader, enabled,
              error == nil, let data = characteristic.value else { return }
        for frame in parser.append(data) {
            lastFrameAt = ProcessInfo.processInfo.systemUptime
            if frame.command == JBDBMSAssembler.basicInfoCommand {
                expectedCommand = JBDBMSAssembler.cellInfoCommand
            } else if frame.command == JBDBMSAssembler.cellInfoCommand {
                expectedCommand = JBDBMSAssembler.basicInfoCommand
            }
            guard let reading = assembler.consume(frame) else { continue }
            sample = BMSSample(reading: reading, uptime: ProcessInfo.processInfo.systemUptime)
            retryDelay = 1
            failedAttempts = 0
            softResetCount = 0
            staleSince = nil
            if lastDropAt > 0,
               ProcessInfo.processInfo.systemUptime - lastDropAt > 45 {
                penalty = 0; lastDropAt = 0
            }
            update("JBD 实时数据已连接")
            onChange?()
        }
        poll()
    }

    func peripheral(_ peripheral: CBPeripheral, didWriteValueFor characteristic: CBCharacteristic, error: Error?) {
        guard peripheral === self.peripheral, characteristic === writer else { return }
        writePending = false
        if let error { failConnection("BMS 读取请求失败：\(error.localizedDescription)") }
    }

    private func tick() {
        guard enabled else { return }
        let now = ProcessInfo.processInfo.systemUptime
        if let sample, !sample.isFresh(at: now, maximumAge: freshnessWindow) {
            update("BMS 数据已过期，自动恢复中…")
        }

        if let peripheral, peripheral.state == .connected {
            // 会话僵死检测：以「最后有效帧」和「本次连接」中较晚的作基准，
            // 否则重连后旧 sample 的时间戳会立刻判超时，陷入重连死循环。
            let anchor = max(sample?.uptime ?? 0, connectedAt ?? 0)
            let silent = now - anchor
            staleSince = silent > 3 ? (staleSince ?? now) : nil
            if silent > 16 {
                failConnection("BMS 连续 \(Int(silent)) 秒无数据，自动重连")
                return
            }
            // 全自动救场：3 秒静默起试一次软重置，间隔逐次拉长，最多 3 次；
            // 三次都救不回来才等到 16 秒做硬重连。
            if silent > 3, softResetCount < 3 { softReset(now: now) }
        } else if let peripheral {
            // 建链阶段卡住：8 秒还没连上就拆掉重来，别让系统一直挂着。
            if now - (connectedAt ?? now) > 8 {
                failConnection("BMS 连接超时，自动重连")
                return
            }
        } else if let selectedID, !disconnecting.contains(selectedID), reconnectWork == nil {
            // 兜底：任何原因让重连计时器丢了，这一轮立刻补上。
            scheduleReconnect()
        }

        // A board that never answers 0x04 must not stall the cycle.
        if expectedCommand != JBDBMSAssembler.basicInfoCommand, now - (lastFrameAt ?? now) > 2.5 {
            expectedCommand = JBDBMSAssembler.basicInfoCommand
        }
        poll()
        onChange?()
    }

    /// Sends the next documented read-only query of the cycle. The two registers
    /// are requested back to back: 0x03 first, 0x04 as soon as 0x03 came back.
    private func poll() {
        guard enabled, let peripheral, peripheral.state == .connected,
              let writer, reader?.isNotifying == true, !writePending else { return }
        let now = ProcessInfo.processInfo.systemUptime
        guard now - lastWriteAt >= 0.05 else { return }
        let type: CBCharacteristicWriteType = writer.properties.contains(.write) ? .withResponse : .withoutResponse
        if type == .withoutResponse, !peripheral.canSendWriteWithoutResponse { return }
        // Only the start of a cycle is paced; the follow-up 0x04 goes out right
        // after 0x03 comes back, so the pair stays together on air.
        let startsCycle = expectedCommand != JBDBMSAssembler.cellInfoCommand
        if startsCycle {
            // 僵死期间用最短间隔持续发查询，既是轮询也是唤醒探测包；
            // 正常状态才按用户设定的间隔走，省电省流量。
            let spacing = staleSince == nil ? min(3, pollInterval + penalty)
                : min(1.2, max(0.8, pollInterval))
            if now - lastCycleAt < spacing - 0.05 { return }
        }
        let request: Data
        switch expectedCommand {
        case JBDBMSAssembler.cellInfoCommand: request = JBDBMSProtocol.cellInfoRequest
        default:
            expectedCommand = JBDBMSAssembler.basicInfoCommand
            request = JBDBMSProtocol.basicInfoRequest
        }
        if startsCycle { lastCycleAt = now }
        writePending = type == .withResponse
        lastWriteAt = now
        peripheral.writeValue(request, for: writer, type: type)
    }

    private func failConnection(_ message: String) {
        registerDrop()
        clearConnection()
        update(message)
        scheduleReconnect()
    }

    /// Marks a link loss so the next cycles are paced wider and the retry loop
    /// stays short: a weak peripheral is usually back within a couple of seconds.
    private func registerDrop() {
        let now = ProcessInfo.processInfo.systemUptime
        lastDropAt = now
        penalty = min(2, penalty + 1)
        retryDelay = 1
        staleSince = nil
    }

    /// 保持蓝牙不断，只重建通信会话：先关订阅、丢缓存解析器，0.3 秒后重新
    /// 发现 FF00 服务并重新订阅 FF01，再把 0x03 查询打出去。保护板的通知
    /// 通道会在静默一段时间后失效，这一步能把数据拉回来而不用重连。
    private func softReset(now: TimeInterval) {
        // 间隔逐次拉长：2.5s → 4s → 6s，既快又不会把 BLE 栈刷爆。
        let spacing: TimeInterval = [2.5, 4, 6][min(softResetCount, 2)]
        guard now - lastSoftResetAt > spacing,
              let peripheral, peripheral.state == .connected else { return }
        lastSoftResetAt = now
        softResetCount += 1
        parser = JBDBMSProtocol(); assembler = JBDBMSAssembler()
        expectedCommand = JBDBMSAssembler.basicInfoCommand
        writePending = false
        lastWriteAt = 0
        lastFrameAt = nil
        if let reader, reader.isNotifying {
            peripheral.setNotifyValue(false, for: reader)
        }
        update("已连接但无报文，软重置通信（第 \(softResetCount) 次）")
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) { [weak self, weak peripheral] in
            guard let self, let peripheral, peripheral === self.peripheral,
                  peripheral.state == .connected else { return }
            peripheral.discoverServices([Self.service])
        }
    }

    private func clearConnection() {
        let previous = peripheral
        peripheral = nil; writer = nil; reader = nil
        connectedAt = nil; writePending = false; lastFrameAt = nil
        parser = JBDBMSProtocol(); assembler = JBDBMSAssembler()
        expectedCommand = JBDBMSAssembler.basicInfoCommand
        previous?.delegate = nil
        if let previous, previous.state != .disconnected {
            disconnecting.insert(previous.identifier)
            central?.cancelPeripheralConnection(previous)
        }
    }

    private func scheduleReconnect() {
        guard enabled, selectedID != nil, reconnectWork == nil, central?.state == .poweredOn else { return }
        let retry = DispatchWorkItem { [weak self] in
            guard let self else { return }
            self.reconnectWork = nil
            self.connectRememberedOrScan()
        }
        let delays: [TimeInterval] = [1, 2, 4, 8]
        let delay = delays[min(failedAttempts, delays.count - 1)]
        reconnectWork = retry
        update("蓝牙已断开，\(Int(delay)) 秒后重连")
        DispatchQueue.main.asyncAfter(deadline: .now() + delay, execute: retry)
        failedAttempts += 1
    }

    private func update(_ text: String) {
        if text != status { status = text; onLog?(text) }
        onChange?()
    }
}
