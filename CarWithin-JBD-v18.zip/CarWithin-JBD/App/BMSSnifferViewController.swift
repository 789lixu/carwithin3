import UIKit

/// 抓包界面：一行状态、一块日志、三个按钮（开始 / 清空 / 导出）。
final class BMSSnifferViewController: UIViewController {
    var onFinish: (() -> Void)?
    private let sniffer = BMSSniffer()
    private let statusLabel = UILabel()
    private let textView = UITextView()
    private let startButton = UIButton(type: .system)
    private let exportButton = UIButton(type: .system)

    override func viewDidLoad() {
        super.viewDidLoad()
        title = "协议抓包"
        view.backgroundColor = .systemBackground
        navigationItem.rightBarButtonItem = UIBarButtonItem(title: "关闭", style: .done, target: self, action: #selector(close))

        statusLabel.numberOfLines = 2
        statusLabel.font = .systemFont(ofSize: 13, weight: .semibold)

        textView.isEditable = false
        textView.font = .monospacedSystemFont(ofSize: 11, weight: .regular)
        textView.backgroundColor = UIColor.secondarySystemBackground
        textView.layer.cornerRadius = 8

        startButton.setTitle("开始抓包", for: .normal)
        startButton.titleLabel?.font = .systemFont(ofSize: 16, weight: .semibold)
        startButton.addTarget(self, action: #selector(toggle), for: .touchUpInside)

        exportButton.setTitle("导出日志", for: .normal)
        exportButton.titleLabel?.font = .systemFont(ofSize: 16, weight: .semibold)
        exportButton.addTarget(self, action: #selector(shareLog), for: .touchUpInside)

        let buttons = UIStackView(arrangedSubviews: [startButton, exportButton])
        buttons.axis = .horizontal
        buttons.distribution = .fillEqually
        buttons.spacing = 12

        let stack = UIStackView(arrangedSubviews: [statusLabel, textView, buttons])
        stack.axis = .vertical
        stack.spacing = 12
        stack.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(stack)
        NSLayoutConstraint.activate([
            stack.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 12),
            stack.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 16),
            stack.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -16),
            stack.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -12),
            textView.heightAnchor.constraint(greaterThanOrEqualToConstant: 260)
        ])

        sniffer.onChange = { [weak self] in self?.render() }
        render()
    }

    deinit { sniffer.stop() }

    private func render() {
        if let level = sniffer.level {
            statusLabel.text = "电量 \(level)%\n" + sniffer.status + " · 日志 \(sniffer.lines.count) 行"
        } else {
            statusLabel.text = sniffer.status + "\n日志 \(sniffer.lines.count) 行"
        }
        let text = sniffer.text()
        if textView.text != text {
            textView.text = text
            if !text.isEmpty {
                let end = NSRange(location: text.count - 1, length: 1)
                textView.scrollRangeToVisible(end)
            }
        }
        startButton.setTitle(sniffer.status == "未开始" || sniffer.status == "已停止" ? "开始抓包" : "重新开始", for: .normal)
    }

    @objc private func toggle() {
        sniffer.stop()
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.4) { [weak self] in
            guard let self else { return }
            self.sniffer.start()
        }
    }

    @objc private func shareLog() {
        let name = "bms-sniffer-" + Self.stamp() + ".txt"
        let url = FileManager.default.temporaryDirectory.appendingPathComponent(name)
        do {
            try sniffer.text().write(to: url, atomically: true, encoding: .utf8)
        } catch {
            let alert = UIAlertController(title: "导出失败", message: error.localizedDescription, preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "好", style: .default))
            present(alert, animated: true)
            return
        }
        let sheet = UIActivityViewController(activityItems: [url], applicationActivities: nil)
        if let popover = sheet.popoverPresentationController {
            popover.sourceView = exportButton
            popover.sourceRect = exportButton.bounds
        }
        present(sheet, animated: true)
    }

    @objc private func close() {
        sniffer.stop()
        onFinish?()
        dismiss(animated: true)
    }

    private static func stamp() -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "MMdd-HHmmss"
        return formatter.string(from: Date())
    }
}
