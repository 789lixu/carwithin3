import UIKit

/// Stores the panel wallpaper chosen from the photo library. The bitmap lives in
/// the app's Documents folder so the overlay can redraw it without the picker.
enum BMSWallpaperStore {
    static let fileName = "bms-panel-wallpaper.jpg"
    private static var cache: UIImage?

    static var url: URL {
        FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
            .appendingPathComponent(fileName)
    }

    static var isAvailable: Bool { FileManager.default.fileExists(atPath: url.path) }

    static func save(_ image: UIImage) {
        guard let data = image.jpegData(compressionQuality: 0.72) ?? image.pngData() else { return }
        cache = nil
        try? data.write(to: url, options: .atomic)
    }

    static func load() -> UIImage? {
        if let cache { return cache }
        guard let image = UIImage(contentsOfFile: url.path) else { return nil }
        cache = image
        return image
    }

    static func clear() {
        cache = nil
        try? FileManager.default.removeItem(at: url)
    }
}

/// Draws the right-side battery column: a slim SOC bar at the very top, the
/// middle left empty for the vehicle's own P card, then pack metrics and a
/// 3-column grid of every cell voltage underneath.
///
/// The canvas is sized in the instrument video's own pixels (848×480, so the
/// 25 % strip is 212×480). Drawing at 1:1 keeps the digits crisp; rendering at
/// 2× and letting the compositor shrink them is what made the first version
/// look soft.
struct BMSPanelRenderer {
    /// Video-pixel canvas for the default 25 % column.
    static let canvasWidth: CGFloat = 212
    static let canvasHeight: CGFloat = 480
    static let aspect: CGFloat = canvasHeight / canvasWidth

    static func render(_ reading: BMSReading?, configuration: BMSCardConfiguration, phase: Double) -> CGImage? {
        let size = CGSize(width: canvasWidth, height: canvasHeight)
        let format = UIGraphicsImageRendererFormat()
        format.scale = 1
        let opacity = CGFloat(min(1, max(0, configuration.backgroundOpacity)))
        let dataColor = BMSThemeColor.color(hex: configuration.dataColorHex)
        let barColor = BMSThemeColor.color(hex: configuration.barColorHex)
        let trackColor = BMSThemeColor.color(hex: configuration.barTrackColorHex)
        return UIGraphicsImageRenderer(size: size, format: format).image { context in
            let cg = context.cgContext
            let panel = CGRect(origin: .zero, size: size)

            // Background: photo wallpaper when enabled, otherwise a dark plate.
            // The column is flush with the video edge, so it is never rounded.
            cg.saveGState()
            cg.clip(to: panel)
            if configuration.wallpaperEnabled, let wallpaper = BMSWallpaperStore.load() {
                let source = wallpaper.size
                if source.width > 0, source.height > 0 {
                    let scale = max(panel.width / source.width, panel.height / source.height)
                    let drawSize = CGSize(width: source.width * scale, height: source.height * scale)
                    wallpaper.draw(in: CGRect(x: (panel.width - drawSize.width) / 2,
                                              y: (panel.height - drawSize.height) / 2,
                                              width: drawSize.width, height: drawSize.height))
                }
                UIColor.black.withAlphaComponent(0.20 + 0.55 * opacity).setFill()
                UIRectFill(panel)
            } else {
                UIColor.black.withAlphaComponent(opacity).setFill()
                UIRectFill(panel)
            }
            cg.restoreGState()

            // Hairline on the left so the column reads as its own strip.
            dataColor.withAlphaComponent(0.28).setFill()
            UIRectFill(CGRect(x: 0, y: 0, width: 1, height: panel.height))

            guard let reading else {
                drawText("等待数据", in: CGRect(x: 4, y: panel.height * 0.55, width: panel.width - 8, height: 24),
                         font: UIFont.monospacedDigitSystemFont(ofSize: 12, weight: .medium),
                         color: dataColor, alignment: .center)
                return
            }

            // Slim SOC bar, kept above the vehicle's P card (top ~6 % of the strip).
            let bar = CGRect(x: 5, y: 5, width: panel.width - 10, height: 28)
            let radius: CGFloat = 11
            trackColor.setFill()
            UIBezierPath(roundedRect: bar, cornerRadius: radius).fill()
            let soc = CGFloat(min(100, max(0, reading.stateOfCharge)))
            let fillWidth = max(0, bar.width * soc / 100)
            if fillWidth > 0 {
                barColor.setFill()
                UIBezierPath(roundedRect: CGRect(x: bar.minX, y: bar.minY, width: fillWidth, height: bar.height),
                             cornerRadius: radius).fill()
            }

            // Charging: breathing glow, a light sweep across the filled part and
            // two comets with fading tails running left to right.
            if configuration.shouldAnimateCharging(reading), fillWidth > 0 {
                drawChargingAnimation(cg: cg, bar: bar, fillWidth: fillWidth,
                                      barColor: barColor, phase: phase)
            }

            let percent = "\(reading.stateOfCharge)%"
            drawText(percent, in: CGRect(x: bar.minX + 4, y: bar.minY + 6, width: bar.width - 8, height: 17),
                     font: UIFont.monospacedDigitSystemFont(ofSize: 14, weight: .bold),
                     color: .white, alignment: .right)

            // The band from y≈33 to y≈250 belongs to the vehicle's P card, so it
            // stays empty on purpose.

            let cells = reading.cells.compactMap { $0 }
            let deltaText = reading.cellDelta.map { String(format: "%.0fmV", ($0 * 1000).rounded()) } ?? "--mV"
            let temperatureText = reading.maximumTemperature.map { String(format: "%.0f°C", $0) } ?? "--°C"
            let alarmColor: UIColor = reading.hasAlarm ? .systemOrange : dataColor

            // Metric rows.
            drawMetric("压差", deltaText, y: 254, color: alarmColor)
            drawMetric("温度", temperatureText, y: 254, color: dataColor, rightHalf: true)
            drawMetric("电流", String(format: "%+.1fA", reading.current), y: 275,
                       color: reading.hasAlarm ? .systemOrange : dataColor)
            drawMetric("功率", "\(reading.power)W", y: 275, color: dataColor, rightHalf: true)

            dataColor.withAlphaComponent(0.35).setFill()
            UIRectFill(CGRect(x: 5, y: 296, width: panel.width - 10, height: 0.7))

            // Every cell voltage, three columns wide, highest and lowest tinted.
            guard !cells.isEmpty else {
                drawText("单体：--", in: CGRect(x: 5, y: 300, width: panel.width - 10, height: 20),
                         font: UIFont.monospacedDigitSystemFont(ofSize: 11, weight: .medium),
                         color: dataColor.withAlphaComponent(0.7), alignment: .left)
                return
            }
            let high = cells.max() ?? 0
            let low = cells.min() ?? 0
            let columns = 3
            let columnWidth = (panel.width - 8) / CGFloat(columns)
            let rowHeight: CGFloat = 22.6
            let top: CGFloat = 300
            for (index, voltage) in cells.enumerated() {
                let column = index % columns
                let row = index / columns
                let x = 4 + CGFloat(column) * columnWidth
                let y = top + CGFloat(row) * rowHeight
                guard y + rowHeight <= panel.height - 1 else { break }
                drawText(String(format: "%02d", index + 1),
                         in: CGRect(x: x, y: y + 5, width: 10, height: 10),
                         font: UIFont.monospacedDigitSystemFont(ofSize: 7, weight: .regular),
                         color: dataColor.withAlphaComponent(0.55), alignment: .left)
                let color: UIColor
                if voltage >= high - 0.0001 { color = .systemRed }
                else if voltage <= low + 0.0001 { color = .systemGreen }
                else { color = dataColor }
                drawText(String(format: "%.3f", voltage),
                         in: CGRect(x: x + 10, y: y + 2, width: columnWidth - 11, height: 17),
                         font: UIFont.monospacedDigitSystemFont(ofSize: 13, weight: .semibold),
                         color: color, alignment: .left)
            }
        }.cgImage
    }

    /// Charging motion: breathing halo, a light sweep inside the filled part and
    /// two comets with fading tails. Everything stays inside the SOC bar so the
    /// P card below is never touched.
    private static func drawChargingAnimation(cg: CGContext, bar: CGRect, fillWidth: CGFloat,
                                              barColor: UIColor, phase: Double) {
        let fillRect = CGRect(x: bar.minX, y: bar.minY, width: fillWidth, height: bar.height)
        let radius: CGFloat = 11
        let path = UIBezierPath(roundedRect: fillRect, cornerRadius: radius)

        // 1. Breathing halo around the filled portion.
        let pulse = CGFloat(0.5 + 0.5 * sin(phase * .pi * 4))
        cg.saveGState()
        cg.setShadow(offset: .zero, blur: 4 + 4 * pulse,
                     color: barColor.withAlphaComponent(0.30 + 0.40 * pulse).cgColor)
        UIColor.white.withAlphaComponent(0.12 + 0.12 * pulse).setStroke()
        let halo = UIBezierPath(roundedRect: fillRect.insetBy(dx: 0.5, dy: 0.5), cornerRadius: radius)
        halo.lineWidth = 1.5
        halo.stroke()
        cg.restoreGState()

        // 2. Light sweep and a glassy top sheen, both clipped to the fill.
        cg.saveGState()
        path.addClip()
        let sweep = max(26, fillWidth * 0.55)
        let sx = bar.minX - sweep + (fillWidth + sweep) * CGFloat(phase)
        let colors = [UIColor.white.withAlphaComponent(0).cgColor,
                      UIColor.white.withAlphaComponent(0.42).cgColor,
                      UIColor.white.withAlphaComponent(0).cgColor]
        let locations: [CGFloat] = [0, 0.5, 1]
        if let gradient = CGGradient(colorsSpace: CGColorSpaceCreateDeviceRGB(),
                                     colors: colors as CFArray, locations: locations) {
            cg.drawLinearGradient(gradient,
                                  start: CGPoint(x: sx, y: bar.minY),
                                  end: CGPoint(x: sx + sweep, y: bar.minY + bar.height * 0.2),
                                  options: [])
        }
        UIColor.white.withAlphaComponent(0.16).setFill()
        UIBezierPath(roundedRect: CGRect(x: fillRect.minX, y: fillRect.minY + 1,
                                         width: fillRect.width, height: bar.height * 0.42),
                     cornerRadius: 9).fill()
        cg.restoreGState()

        // 3. Two comets with fading tails.
        let start = bar.minX + 8
        let end = bar.maxX - 8
        let dotRadius: CGFloat = 3.0
        for comet in 0..<2 {
            var progress = phase + Double(comet) * 0.5
            progress -= floor(progress)
            let cx = start + (end - start) * CGFloat(progress)
            for step in stride(from: 4, through: 1, by: -1) {
                let back = cx - CGFloat(step) * 3.4
                guard back > bar.minX + 2 else { continue }
                let alpha = CGFloat(0.40 - Double(step) * 0.08)
                let size = dotRadius * (1 - CGFloat(step) * 0.13)
                barColor.withAlphaComponent(max(0.05, alpha)).setFill()
                UIBezierPath(roundedRect: CGRect(x: back - size, y: bar.midY - size * 0.6,
                                                 width: size * 1.6, height: size * 1.2),
                             cornerRadius: size * 0.6).fill()
            }
            barColor.withAlphaComponent(0.92).setFill()
            UIBezierPath(ovalIn: CGRect(x: cx - dotRadius * 1.8, y: bar.midY - dotRadius * 1.8,
                                        width: dotRadius * 3.6, height: dotRadius * 3.6)).fill()
            UIColor.white.setFill()
            UIBezierPath(ovalIn: CGRect(x: cx - dotRadius * 0.7, y: bar.midY - dotRadius * 0.7,
                                        width: dotRadius * 1.4, height: dotRadius * 1.4)).fill()
        }
    }

    private static func drawMetric(_ title: String, _ value: String, y: CGFloat,
                                   color: UIColor, rightHalf: Bool = false) {
        let width = (canvasWidth - 4) / 2
        let x: CGFloat = rightHalf ? 2 + width : 4
        drawText(title, in: CGRect(x: x, y: y + 3, width: 20, height: 14),
                 font: UIFont.systemFont(ofSize: 9, weight: .regular),
                 color: color.withAlphaComponent(0.62), alignment: .left)
        drawText(value, in: CGRect(x: x + 19, y: y, width: width - 20, height: 17),
                 font: UIFont.monospacedDigitSystemFont(ofSize: 12.5, weight: .semibold),
                 color: color, alignment: .left)
    }

    private static func drawText(_ text: String, in rect: CGRect, font: UIFont,
                                 color: UIColor, alignment: NSTextAlignment) {
        let paragraph = NSMutableParagraphStyle()
        paragraph.alignment = alignment
        paragraph.lineBreakMode = .byTruncatingTail
        (text as NSString).draw(in: rect, withAttributes: [
            .font: font, .foregroundColor: color, .paragraphStyle: paragraph
        ])
    }
}
