import Foundation

/// Shared card content and scale for the phone and instrument video.
public struct BMSCardConfiguration: Equatable, Sendable {
    public enum Field: String, CaseIterable, Sendable {
        case charge, voltage, temperature, current, power, cellDelta

        public var title: String {
            switch self {
            case .charge: "电量"
            case .voltage: "总压"
            case .temperature: "最高温度"
            case .current: "电流"
            case .power: "功率"
            case .cellDelta: "单体压差"
            }
        }

        public func text(_ reading: BMSReading) -> String {
            switch self {
            case .charge: return "\(reading.stateOfCharge)%"
            case .voltage: return String(format: "%.2fV", reading.voltage)
            case .temperature: return reading.maximumTemperature.map { String(format: "%.0f°C", $0) } ?? "--°C"
            case .current: return String(format: "%+.1fA", reading.current)
            case .power: return "\(reading.power)W"
            case .cellDelta: return "Δ" + (reading.cellDelta.map { String(format: "%.0fmV", ($0 * 1000).rounded()) } ?? "--mV")
            }
        }
    }

    public enum Size: Int, CaseIterable, Sendable {
        case small, medium, large
        public var title: String { ["小", "中", "大"][rawValue] }
        /// Both compositors use this fraction of their video width.
        public var widthFraction: Double { [0.36, 0.46, 0.58][rawValue] }
    }

    /// Keep the two original right-side values so existing preferences migrate.
    public enum Position: Int, CaseIterable, Sendable {
        case topRight, bottomRight, topLeft, bottomLeft
        public var title: String { ["右上角", "右下角", "左上角", "左下角"][rawValue] }
        public var isAtTop: Bool { self == .topRight || self == .topLeft }
        public var isAtRight: Bool { self == .topRight || self == .bottomRight }
    }

    public enum Background: Int, CaseIterable, Sendable {
        case light, standard, opaque
        public var title: String { ["轻透", "标准", "不透明"][rawValue] }
        public var opacity: Double { [0.45, 0.86, 1][rawValue] }
    }

    /// Two presentations share one configuration: the original single line bar
    /// and the taller battery panel with a charge bar and a data row.
    public enum Layout: Int, CaseIterable, Sendable {
        case bar, panel
        public var title: String { ["长条", "面板"][rawValue] }
    }

    public static let compactFields: [Field] = [.charge, .voltage, .cellDelta]
    public private(set) var fields: [Field]
    public var size: Size
    public var position: Position
    public var background: Background
    /// Bar text colour as RRGGBB; the compositors parse it into UIColor.
    public var textColorHex: String
    /// 0 renders a completely transparent bar, 1 a solid black bar.
    public var backgroundOpacity: Double
    /// Free position expressed as the centre of the bar, 0...1 across the video.
    public var anchorX: Double
    /// Free position expressed as the centre of the bar, 0...1 down the video.
    public var anchorY: Double
    /// Panel presentation and its colours.
    public var layout: Layout
    /// SOC bar fill colour as RRGGBB.
    public var barColorHex: String
    /// SOC bar empty track colour as RRGGBB.
    public var barTrackColorHex: String
    /// Colour of the data row and the SOC percentage text.
    public var dataColorHex: String
    /// Panel width when the layout is `.panel`, as a fraction of the video.
    public var panelWidthFraction: Double
    /// A photo stored by the app is used as the panel wallpaper when true.
    public var wallpaperEnabled: Bool
    /// Play the charging dot while the pack reports charge current.
    public var chargingAnimation: Bool
    /// Manual override that plays the charging dot even when idle.
    public var forceChargingAnimation: Bool
    /// Width of the vehicle's own strip on the left, so our panel never slides
    /// underneath the P card and its SOC bar.
    public var leftInsetFraction: Double

    /// Missing/invalid saved preferences preserve the original six-field card.
    public init(savedFields: [String]? = nil, sizeRawValue: Int? = nil,
                positionRawValue: Int? = nil, backgroundRawValue: Int? = nil,
                textColorHex: String? = nil, backgroundOpacity: Double? = nil,
                anchorX: Double? = nil, anchorY: Double? = nil,
                layoutRawValue: Int? = nil, barColorHex: String? = nil,
                barTrackColorHex: String? = nil, dataColorHex: String? = nil,
                panelWidthFraction: Double? = nil, wallpaperEnabled: Bool = false,
                chargingAnimation: Bool = true, forceChargingAnimation: Bool = false,
                leftInsetFraction: Double? = nil) {
        var seen = Set<Field>()
        let normalized = (savedFields?.compactMap(Field.init(rawValue:)) ?? Field.allCases)
            .filter { seen.insert($0).inserted }
        fields = normalized.isEmpty ? Field.allCases : normalized
        size = sizeRawValue.flatMap(Size.init(rawValue:)) ?? .small
        position = positionRawValue.flatMap(Position.init(rawValue:)) ?? .topRight
        let style = backgroundRawValue.flatMap(Background.init(rawValue:)) ?? .standard
        background = style
        self.textColorHex = BMSCardConfiguration.normalizedHex(textColorHex) ?? "FFFFFF"
        self.backgroundOpacity = min(1, max(0, backgroundOpacity ?? style.opacity))
        let anchoredX = anchorX ?? (position.isAtRight ? 0.82 : 0.18)
        let anchoredY = anchorY ?? (layoutRawValue == Layout.panel.rawValue ? 0.82
                                    : (position.isAtTop ? 0.12 : 0.88))
        self.anchorX = min(1, max(0, anchoredX))
        self.anchorY = min(1, max(0, anchoredY))
        self.layout = layoutRawValue.flatMap(Layout.init(rawValue:)) ?? .bar
        self.barColorHex = BMSCardConfiguration.normalizedHex(barColorHex) ?? "22D07A"
        self.barTrackColorHex = BMSCardConfiguration.normalizedHex(barTrackColorHex) ?? "3A3A3C"
        self.dataColorHex = BMSCardConfiguration.normalizedHex(dataColorHex) ?? "EDEDF0"
        // The panel is a full-height strip; 0.25 keeps it inside the vehicle strip
        // that already holds the P card, and the old 0.94 default is discarded.
        let storedPanelWidth = panelWidthFraction ?? 0.25
        self.panelWidthFraction = (storedPanelWidth >= 0.18 && storedPanelWidth <= 0.42)
            ? storedPanelWidth : 0.25
        self.wallpaperEnabled = wallpaperEnabled
        self.chargingAnimation = chargingAnimation
        self.forceChargingAnimation = forceChargingAnimation
        self.leftInsetFraction = min(0.6, max(0, leftInsetFraction ?? 0))
    }

    /// Charge current is positive; a small threshold keeps idle noise from
    /// starting the animation.
    public func shouldAnimateCharging(_ reading: BMSReading?) -> Bool {
        guard layout == .panel else { return false }
        if forceChargingAnimation { return true }
        guard chargingAnimation, let reading else { return false }
        return reading.current > 0.2 || reading.stateCode == 2
    }

    /// Accepts "#RRGGBB", "RRGGBB" or nil; anything malformed falls back to white.
    public static func normalizedHex(_ raw: String?) -> String? {
        guard let raw else { return nil }
        let trimmed = raw.replacingOccurrences(of: "#", with: "")
            .trimmingCharacters(in: .whitespacesAndNewlines).uppercased()
        guard trimmed.count == 6, UInt32(trimmed, radix: 16) != nil else { return nil }
        return trimmed
    }

    /// Keep at least one metric visible, preserving the user's preferred order.
    @discardableResult
    public mutating func set(_ field: Field, visible: Bool) -> Bool {
        if !visible, fields == [field] { return false }
        if visible {
            if !fields.contains(field) { fields.append(field) }
        } else { fields.removeAll { $0 == field } }
        return true
    }

    public mutating func move(_ field: Field, to destination: Int) {
        guard let index = fields.firstIndex(of: field), fields.indices.contains(destination) else { return }
        fields.remove(at: index)
        fields.insert(field, at: destination)
    }

    /// One horizontal bar: every selected metric stays on a single line so the
    /// composited card never stacks rows on the instrument.
    public func lines(for reading: BMSReading) -> [String] {
        let tokens = fields.map { $0.text(reading) }
        var line = tokens.joined(separator: "  ")
        if reading.hasAlarm { line += " · 告警" }
        return [line]
    }
}
