// JBD / 嘉佰达 BMS framing and field layout.
//
// Frame: 0xDD | command | status | length | payload… | checksumHi | checksumLo | 0x77
// Checksum: 0x10000 – (sum of bytes from command through the last payload byte),
// transmitted big endian. Verified against the vendor document
// 《嘉佰达软件板通用协议 v12》 and cross-checked with esphome-jbd-bms (MIT).
//
// Only the two read-only queries the vendor documents are implemented here
// (register 0x03 basic telemetry, register 0x04 cell voltages). No control,
// parameter-write, MOS-switch, factory or SOC-reset command is exposed.
import Foundation

/// One validated telemetry snapshot. Every field comes from a checksum-checked
/// frame, so views never have to guess whether a value is real.
public struct BMSReading: Equatable {
    public let voltage: Double
    /// Signed pack current in amperes: charging is positive, discharging negative.
    public let current: Double
    public let power: Int
    public let stateOfCharge: Int
    /// JBD does not report state of health in the 0x03 frame.
    public let stateOfHealth: Int?
    /// 1 idle, 2 charging, 4 discharging, 5 protection tripped. 0/3 unused.
    public let stateCode: Int
    public let capacityAh: Double
    public let remainingAh: Double
    public let cells: [Double?]
    public let temperatures: [Double?]
    public let mosTemperature: Double?
    public let protectionBits: UInt64
    /// JBD reports no separate warning mask; kept so callers stay source compatible.
    public let warningBits: UInt64

    /// Protection bits are a flat 16-bit mask, unlike ANT's split state/warning words.
    public var alarmBits: UInt64 { protectionBits & 0xffff }
    public var hasAlarm: Bool { alarmBits != 0 }
    public var maximumTemperature: Double? { temperatures.compactMap { $0 }.max() }
    public var cellDelta: Double? {
        let values = cells.compactMap { $0 }
        guard let low = values.min(), let high = values.max() else { return nil }
        return high - low
    }

    /// Names of the 16 documented protection bits, lowest bit first.
    public static let protectionNames = [
        "单体过压", "单体欠压", "总压过压", "总压欠压",
        "充电高温", "充电低温", "放电高温", "放电低温",
        "充电过流", "放电过流", "短路保护", "前端 IC 故障",
        "MOS 软锁", "充电超时", "保留 14", "保留 15",
    ]

    public var protectionDescriptions: [String] {
        let mask = alarmBits
        return Self.protectionNames.enumerated().compactMap { index, name in
            mask & (UInt64(1) << UInt64(index)) != 0 ? name : nil
        }
    }
}

public struct BMSSample: Equatable {
    public let reading: BMSReading
    public let uptime: TimeInterval

    public init(reading: BMSReading, uptime: TimeInterval) {
        self.reading = reading; self.uptime = uptime
    }

    public func isFresh(at now: TimeInterval, maximumAge: TimeInterval = 5) -> Bool {
        now >= uptime && now - uptime <= maximumAge
    }
}

/// One decoded response frame. Status 0x00 means success; rejections never reach
/// the assembler, so a failed read can never republish stale telemetry.
public struct JBDBMSFrame: Equatable {
    public let command: UInt8
    public let status: UInt8
    public let payload: Data

    public init(command: UInt8, status: UInt8, payload: Data) {
        self.command = command; self.status = status; self.payload = payload
    }
}

/// Streaming framer. BLE notifications arrive in arbitrary fragments, so bytes
/// are buffered, resynchronised on 0xDD and every frame is checksum verified.
public struct JBDBMSProtocol {
    public static let basicInfoRequest = Data([0xdd, 0xa5, 0x03, 0x00, 0xff, 0xfd, 0x77])
    public static let cellInfoRequest = Data([0xdd, 0xa5, 0x04, 0x00, 0xff, 0xfc, 0x77])
    public static let maximumBufferedBytes = 4096
    private var bytes: [UInt8] = []
    public var bufferedByteCount: Int { bytes.count }

    public init() {}

    public static func checksum<C: Collection>(_ bytes: C) -> UInt16 where C.Element == UInt8 {
        var sum: UInt32 = 0
        for byte in bytes { sum &+= UInt32(byte) }
        return UInt16(truncatingIfNeeded: 0x1_0000 &- sum)
    }

    public mutating func append(_ data: Data) -> [JBDBMSFrame] {
        bytes.append(contentsOf: data.suffix(Self.maximumBufferedBytes))
        if bytes.count > Self.maximumBufferedBytes {
            bytes.removeFirst(bytes.count - Self.maximumBufferedBytes)
        }
        var frames: [JBDBMSFrame] = []
        while bytes.count >= 7 {
            guard bytes[0] == 0xdd else { bytes.removeFirst(); continue }
            let length = Int(bytes[3])
            // A stray 0xDD inside noise must not make the framer wait for bytes
            // that can never form a frame, so implausible headers resync at once.
            guard Self.isPlausible(command: bytes[1], length: length) else { bytes.removeFirst(); continue }
            let body = length + 7
            guard bytes.count >= body else { break }
            guard bytes[body - 1] == 0x77 else { bytes.removeFirst(); continue }
            let expected = Self.checksum(bytes[2..<(4 + length)])
            let received = UInt16(bytes[4 + length]) << 8 | UInt16(bytes[5 + length])
            guard received == expected else { bytes.removeFirst(); continue }
            let command = bytes[1], status = bytes[2]
            let payload = Data(bytes[4..<(4 + length)])
            bytes.removeFirst(body)
            // A non-zero status is a rejection; drop it instead of publishing.
            if status == 0 { frames.append(JBDBMSFrame(command: command, status: status, payload: payload)) }
        }
        return frames
    }

    /// The registers this app reads have a fixed shape and every documented JBD
    /// payload is at most 64 bytes; anything else is treated as noise.
    static func isPlausible(command: UInt8, length: Int) -> Bool {
        switch command {
        // Firmware DB24SF01 v80 appends one extra status byte after the
        // documented 23, so lengths are 23 + 1 + 2*probes (odd offsets). Only
        // the documented minimum/maximum are enforced here.
        case 0x03: return length >= 23 && length <= 63
        case 0x04, 0x05: return length >= 2 && length <= 64 && length % 2 == 0
        default: return length >= 1 && length <= 64
        }
    }
}

/// Assembles the 0x03 / 0x04 responses of one poll cycle into a reading.
/// Basic info is published immediately, cells upgrade the same reading a few
/// milliseconds later, so the overlay never flashes empty values.
public struct JBDBMSAssembler {
    public static let basicInfoCommand: UInt8 = 0x03
    public static let cellInfoCommand: UInt8 = 0x04

    private struct BasicInfo {
        let voltage: Double
        let current: Double
        let remainingAh: Double
        let capacityAh: Double
        let stateOfCharge: Int
        let protection: UInt16
        let cellCount: Int
        let temperatures: [Double?]
    }

    private var basic: BasicInfo?
    private var cells: [Double?] = []

    public init() {}

    public mutating func reset() {
        basic = nil
        cells = []
    }

    public mutating func consume(_ frame: JBDBMSFrame) -> BMSReading? {
        switch frame.command {
        case Self.basicInfoCommand:
            guard let info = Self.basicInfo(frame.payload) else { return nil }
            basic = info
            if cells.count != info.cellCount {
                cells = Array(repeating: nil, count: info.cellCount)
            }
            return Self.reading(info, cells: cells)
        case Self.cellInfoCommand:
            guard let decoded = Self.cellVoltages(frame.payload) else { return nil }
            cells = decoded
            guard let basic else { return nil }
            return Self.reading(basic, cells: cells)
        default:
            return nil
        }
    }

    private static func reading(_ info: BasicInfo, cells: [Double?]) -> BMSReading {
        let state: Int
        if info.protection != 0 { state = 5 }
        else if info.current > 0.3 { state = 2 }
        else if info.current < -0.3 { state = 4 }
        else { state = 1 }
        return BMSReading(voltage: info.voltage, current: info.current,
            power: Int((info.voltage * info.current).rounded()),
            stateOfCharge: info.stateOfCharge, stateOfHealth: nil, stateCode: state,
            capacityAh: info.capacityAh, remainingAh: info.remainingAh,
            cells: cells, temperatures: info.temperatures,
            // The second probe is the power-tube sensor on the boards we support.
            mosTemperature: info.temperatures.count > 1 ? info.temperatures[1] : nil,
            protectionBits: UInt64(info.protection), warningBits: 0)
    }

    /// Register 0x03: 23 bytes plus one 16-bit value per reported probe.
    private static func basicInfo(_ payload: Data) -> BasicInfo? {
        let bytes = [UInt8](payload)
        guard bytes.count >= 23 else { return nil }
        func u16(_ index: Int) -> UInt16 {
            UInt16(bytes[index]) << 8 | UInt16(bytes[index + 1])
        }
        // Bit 7 of the MOS byte selects the 100 mA / 100 mAh unit of newer boards.
        let scale = (bytes[20] & 0x80) != 0 ? 0.1 : 0.01
        let voltage = Double(u16(0)) / 100
        guard voltage > 1, voltage <= 250 else { return nil }
        let stateOfCharge = Int(bytes[19])
        guard (0...100).contains(stateOfCharge) else { return nil }
        let temperatureCount = min(Int(bytes[22]), 8)
        let available = (bytes.count - 23) / 2
        var temperatures: [Double?] = []
        for index in 0..<min(temperatureCount, available) {
            let celsius = (Double(u16(23 + index * 2)) - 2731) / 10
            temperatures.append((-40...125).contains(celsius) ? celsius : nil)
        }
        return BasicInfo(voltage: voltage,
            current: Double(Int16(bitPattern: u16(2))) * scale,
            remainingAh: Double(u16(4)) * scale, capacityAh: Double(u16(6)) * scale,
            stateOfCharge: stateOfCharge, protection: u16(16),
            cellCount: Int(bytes[21]), temperatures: temperatures)
    }

    /// Register 0x04: one 16-bit millivolt value per cell.
    static func cellVoltages(_ payload: Data) -> [Double?]? {
        let bytes = [UInt8](payload)
        guard bytes.count >= 2, bytes.count <= 64, bytes.count % 2 == 0 else { return nil }
        let raw = (0..<(bytes.count / 2)).map { index in
            UInt16(bytes[index * 2]) << 8 | UInt16(bytes[index * 2 + 1])
        }
        guard let highest = raw.max() else { return nil }
        // Current firmware reports millivolts; older boards use 10 mV steps.
        let divisor: Double = highest > 1000 ? 1000 : 100
        return raw.map { value in
            let volts = Double(value) / divisor
            return (0.5...6).contains(volts) ? volts : nil
        }
    }
}
