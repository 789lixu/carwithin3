# 从源码构建「嘉佰达 JBD」未签名 IPA

本仓库把 CarWithin 1.0.5 里的蚂蚁保护板（ANT BMS）换成了嘉佰达（JBD）保护板。
iOS 应用必须用 Xcode 编译，Windows 上做不了，所以下面的流程全部在 macOS 上完成：
要么用 GitHub Actions 的免费 macOS runner（推荐，不用自己的电脑），要么用你手上的 Mac。

最终产物是 `CarWithin-JBD-unsigned.ipa`：**未签名**，用自己的证书签一下就能装。

## 方式一：GitHub Actions（不用 Mac）

1. 在 GitHub 新建一个仓库（Public 即可，Actions 对公开仓库免费）。
2. 把本目录的全部文件上传上去（网页端直接把文件夹拖进上传框即可，`.github` 目录也要一起上传）。
3. 打开仓库的 **Actions → Build unsigned IPA (JBD) → Run workflow**。
   - `runner` 保持 `macos-15`。如果构建报 Xcode/SDK 相关错误，改成 `macos-26` 再跑一次。
   - `identity` 保持 `true`：这会把官方 1.0.5 包里的 `certificate.p7b`、`leaf.cer`、`private.x963` 复制进 App，少了它 App 能装但连不上 CarPlay。
   - `bundle_id` 默认 `local.tds.carkit`，要和其他安装包共存就改掉。
4. 跑完（约 5～10 分钟）在该次运行的 **Artifacts** 里下载 `CarWithin-JBD-unsigned-ipa`，解压得到 IPA 和 `SHA256SUMS.txt`。

流水线顺序：先跑纯 Swift 的 JBD 解码用例（`Tools/test_bms.sh`，字段偏移或校验错会直接失败），
再生成 Xcode 工程，最后 `CODE_SIGNING_ALLOWED=NO` 构建并打包成 `Payload/TDSCarKit.app`。

## 方式二：自己的 Mac

```sh
xcode-select -p            # 需要 Xcode，不是只有 Command Line Tools
swift --version            # 5.9 以上

# 1. 放好配件身份三件套（从官方 1.0.5 IPA 的 Payload/TDSCarKit.app/ 里取出来）
mkdir -p App/BundledIdentity
cp certificate.p7b leaf.cer private.x963 App/BundledIdentity/

# 2. 先验证解码逻辑（可选但建议）
bash Tools/test_bms.sh

# 3. 生成工程并构建未签名包
python3 Tools/generate_project.py
xcodebuild -project TDSCarKit.xcodeproj -scheme TDSCarKit \
  -configuration Release -sdk iphoneos \
  -destination 'generic/platform=iOS' \
  CODE_SIGNING_ALLOWED=NO CODE_SIGNING_REQUIRED=NO CODE_SIGN_IDENTITY="" \
  -derivedDataPath build/source

# 4. 打包成 IPA
mkdir -p out/Payload
cp -R build/source/Build/Products/Release-iphoneos/TDSCarKit.app out/Payload/
rm -rf out/Payload/TDSCarKit.app/_CodeSignature
(cd out && zip -qry ../CarWithin-JBD-unsigned.ipa Payload)
shasum -a 256 CarWithin-JBD-unsigned.ipa
```

想直接在自己的证书下构建（不手动签名）时，去掉 `CODE_SIGNING_ALLOWED=NO`，改用
`TDS_DEVELOPMENT_TEAM` 和 `TDS_BUNDLE_IDENTIFIER` 环境变量指定团队和包名后再执行
`python3 Tools/generate_project.py`，然后 `xcodebuild archive` + `-exportArchive`。

## 签名安装

- 免费 Apple ID：Windows 上用 Sideloadly 拖入 IPA，7 天有效；或在 iPhone 上用 AltStore / SideStore。
- 付费个人/企业证书：ESign、轻松签、爱思助手等导入 IPA 后选证书签名，注意把设备 UDID 加进描述文件。
- 包内只有 `com.apple.developer.networking.wifi-info` 一项 entitlements，普通证书即可签名，不需要 CarPlay 专用权限。
- 不要用「仅重打包 / 去签名」流程，那样得到仍是未签名包，安装会失败。

## 换成别的 Bundle ID 或改名

- 包名：`TDS_BUNDLE_IDENTIFIER=com.example.carwithin python3 Tools/generate_project.py`
- 显示名：改 `App/Info.plist` 的 `CFBundleDisplayName` 与 `CFBundleName`；图标是 `App/Assets.xcassets/AppIcon.appiconset/AppIcon.png`。
- 版本号：`App/Info.plist` 的 `CFBundleShortVersionString` / `CFBundleVersion`。

## 与上一版（ANT）的差异

| 项目 | 蚂蚁 ANT（原版） | 本仓库（JBD） |
| --- | --- | --- |
| 蓝牙服务 | FFE0，收发都是 FFE1 | FF00，通知 FF01，写入 FF02 |
| 帧格式 | `7E A1 … AA 55`，CRC16/Modbus | `DD 命令 状态 长度 数据 校验 77`，和为 0x10000 − 求和 |
| 查询 | 单条实时帧 | 0x03 基础信息 + 0x04 单体电压 |
| 电流/容量单位 | 固定 | 0.01 A/Ah，MOS 位 bit7 置位时 0.1 A/Ah |
| 单体电压 | 0.001 V 带标志位 | mV，旧固件 10 mV 自动判别 |
| 温度 | 直接摄氏 | (raw − 2731) / 10 |
| 保护位 | 64 位状态+告警 | 16 位保护位，附 16 项中文名称 |
| 健康度 SOH | 有 | JBD 0x03 不上报，显示为空 |
| 源码结构 | ANTBMS* | JBDBMSProtocol / JBDBMSAssembler / JBDBMSClient / JBDBMSController / BMSCardConfiguration |

旧版本保存的偏好会一次性迁移（`antBMS*` → `jbdBMS*`），已记住的设备、卡片布局和开关不会丢。
