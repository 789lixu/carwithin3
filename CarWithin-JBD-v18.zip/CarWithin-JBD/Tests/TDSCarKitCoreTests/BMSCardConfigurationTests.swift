import XCTest
@testable import TDSCarKitCore

final class BMSCardConfigurationTests: XCTestCase {
    private func reading(cells: [Double?] = [4.1, nil, 4.106], temperatures: [Double?] = [nil, 14],
                         protection: UInt64 = 0) -> BMSReading {
        BMSReading(voltage: 82.78, current: -12.3, power: -1018, stateOfCharge: 78,
            stateOfHealth: nil, stateCode: 4, capacityAh: 170, remainingAh: 131.92,
            cells: cells, temperatures: temperatures, mosTemperature: 15,
            protectionBits: protection, warningBits: 0)
    }

    func testExistingUsersKeepAllSixMetricsInTwoLines() {
        let card = BMSCardConfiguration()
        XCTAssertEqual(card.size, .medium)
        XCTAssertEqual(card.lines(for: reading()), ["JBD  78%  82.78V  14°C", "-12.3A  -1018W  压差 6mV"])
    }

    func testCompactCardKeepsVoltageAndSpreadOnOneLine() {
        let card = BMSCardConfiguration(savedFields: BMSCardConfiguration.compactFields.map(\.rawValue))
        XCTAssertEqual(card.lines(for: reading()), ["JBD  78%  82.78V  压差 6mV"])
    }

    func testSavedFieldsNormalizeDuplicatesAndUnknownValues() {
        let card = BMSCardConfiguration(savedFields: ["cellDelta", "unknown", "voltage", "cellDelta"], sizeRawValue: 99)
        XCTAssertEqual(card.fields, [.cellDelta, .voltage])
        XCTAssertEqual(card.size, .medium)
        XCTAssertEqual(BMSCardConfiguration(savedFields: []).fields, BMSCardConfiguration.Field.allCases)
        XCTAssertEqual(BMSCardConfiguration(savedFields: ["unknown"]).fields, BMSCardConfiguration.Field.allCases)
    }

    func testLastMetricCannotBeHiddenAndSelectionCanBeSavedAndRestored() {
        var card = BMSCardConfiguration(savedFields: ["cellDelta"], sizeRawValue: 2)
        XCTAssertFalse(card.set(.cellDelta, visible: false))
        XCTAssertTrue(card.set(.voltage, visible: true))
        XCTAssertTrue(card.set(.cellDelta, visible: false))
        let restored = BMSCardConfiguration(savedFields: card.fields.map(\.rawValue), sizeRawValue: card.size.rawValue)
        XCTAssertEqual(restored, card)
        XCTAssertEqual(restored.fields, [.voltage])
    }

    func testMissingSensorsAreUnknownAndAlarmSurvivesFieldSelection() {
        let card = BMSCardConfiguration(savedFields: ["temperature", "cellDelta"])
        XCTAssertEqual(card.lines(for: reading(cells: [nil, nil], temperatures: [], protection: 1)),
            ["JBD  --°C  压差 --mV · 告警"])
    }

    func testCustomOrderIsRenderedAndSurvivesTogglingAndRestoring() {
        var card = BMSCardConfiguration(savedFields: ["cellDelta", "voltage", "charge"])
        XCTAssertEqual(card.lines(for: reading()), ["JBD  压差 6mV  82.78V  78%"])
        card.move(.charge, to: 0)
        XCTAssertEqual(card.fields, [.charge, .cellDelta, .voltage])
        card.set(.current, visible: true)
        XCTAssertEqual(card.fields, [.charge, .cellDelta, .voltage, .current])
        card.set(.voltage, visible: false)
        XCTAssertEqual(card.fields, [.charge, .cellDelta, .current])
        let restored = BMSCardConfiguration(savedFields: card.fields.map(\.rawValue),
            sizeRawValue: card.size.rawValue, positionRawValue: card.position.rawValue,
            backgroundRawValue: card.background.rawValue)
        XCTAssertEqual(restored, card)
        let previous = card
        card.move(.temperature, to: 0)
        card.move(.charge, to: -1)
        card.move(.charge, to: 99)
        XCTAssertEqual(card, previous)
    }

    func testExistingPositionsAndBackgroundSurviveUpgrade() {
        XCTAssertEqual(BMSCardConfiguration(positionRawValue: 0).position, .topRight)
        XCTAssertEqual(BMSCardConfiguration(positionRawValue: 1).position, .bottomRight)
        let card = BMSCardConfiguration(positionRawValue: 2, backgroundRawValue: 0)
        XCTAssertEqual(card.position, .topLeft)
        XCTAssertTrue(card.position.isAtTop)
        XCTAssertFalse(card.position.isAtRight)
        XCTAssertEqual(card.background.opacity, 0.45)
        let fallback = BMSCardConfiguration(positionRawValue: 99, backgroundRawValue: 99)
        XCTAssertEqual(fallback.position, .topRight)
        XCTAssertEqual(fallback.background.opacity, 0.86)
        XCTAssertFalse(BMSCardConfiguration.Position.bottomLeft.isAtTop)
        XCTAssertFalse(BMSCardConfiguration.Position.bottomLeft.isAtRight)
    }

}
