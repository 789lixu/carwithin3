import XCTest
@testable import TDSCarKitCore

// Frames constructed from the vendor document 《嘉佰达软件板通用协议 v12》:
//   0xDD | command | status | length | payload… | checksumHi | checksumLo | 0x77
// The field layout is cross-checked against esphome-jbd-bms (MIT).
final class JBDBMSProtocolTests: XCTestCase {
    /// 4S / 15.59 V / 100 % / 3 probes — the worked example from the vendor document.
    private let basic = Data([0xdd, 0x03, 0x00, 0x1d, 0x06, 0x17, 0x00, 0x00, 0x01, 0xf3, 0x01, 0xf4,
        0x00, 0x00, 0x2c, 0x7c, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x80, 0x64, 0x03, 0x04, 0x03, 0x0b,
        0x8d, 0x0b, 0x8c, 0x0b, 0x88, 0xfa, 0x85, 0x77])
    /// 3.899 / 3.888 / 3.885 / 3.889 V in millivolts.
    private let cells = Data([0xdd, 0x04, 0x00, 0x08, 0x0f, 0x3b, 0x0f, 0x30, 0x0f, 0x2d, 0x0f, 0x31,
        0xfe, 0xf3, 0x77])

    private func frame(_ command: UInt8, status: UInt8 = 0, payload: [UInt8]) -> Data {
        var bytes = [UInt8]([0xdd, command, status, UInt8(truncatingIfNeeded: payload.count)]) + payload
        let checksum = JBDBMSProtocol.checksum(bytes[2...])
        bytes += [UInt8(checksum >> 8), UInt8(truncatingIfNeeded: checksum), 0x77]
        return Data(bytes)
    }

    private func u16(_ value: Int) -> [UInt8] { [UInt8((value >> 8) & 0xff), UInt8(value & 0xff)] }

    /// Register 0x03 payload with the documented 23-byte core plus one probe each.
    private func basicPayload(voltage: Double, current: Double, soc: Int, protection: UInt16,
                              cellCount: Int, temperatures: [Double], mos: UInt8 = 0x03,
                              remainingAh: Double = 131.92, capacityAh: Double = 170) -> [UInt8] {
        let currentRaw = Int((current * 100).rounded())
        let currentBits = UInt16(bitPattern: Int16(clamping: currentRaw))
        var payload = u16(Int((voltage * 100).rounded()))
        payload += [UInt8(currentBits >> 8), UInt8(truncatingIfNeeded: currentBits)]
        payload += u16(Int((remainingAh * 100).rounded()))
        payload += u16(Int((capacityAh * 100).rounded()))
        payload += u16(120)                                   // cycles
        payload += u16(0x2c7c)                                // production date
        payload += [0, 0, 0, 0]                               // balance bitmask
        payload += u16(Int(protection))
        payload += [0x80, UInt8(truncatingIfNeeded: soc), mos, UInt8(truncatingIfNeeded: cellCount),
                    UInt8(truncatingIfNeeded: temperatures.count)]
        for temperature in temperatures {
            payload += u16(Int((temperature * 10 + 2731).rounded()))
        }
        return payload
    }

    func testChecksumMatchesVendorExample() {
        XCTAssertEqual(JBDBMSProtocol.checksum(basic[2..<33]), 0xfa85)
        XCTAssertEqual(JBDBMSProtocol.checksum(cells[2..<12]), 0xfef3)
    }

    func testRequestsAreTheDocumentedReadOnlyQueries() {
        XCTAssertEqual(JBDBMSProtocol.basicInfoRequest, Data([0xdd, 0xa5, 0x03, 0x00, 0xff, 0xfd, 0x77]))
        XCTAssertEqual(JBDBMSProtocol.cellInfoRequest, Data([0xdd, 0xa5, 0x04, 0x00, 0xff, 0xfc, 0x77]))
    }

    func testVendorExampleFramePublishesBasicTelemetry() throws {
        var parser = JBDBMSProtocol()
        var assembler = JBDBMSAssembler()
        let frames = parser.append(basic)
        XCTAssertEqual(frames.count, 1)
        XCTAssertEqual(frames.first?.command, 0x03)
        let reading = try XCTUnwrap(assembler.consume(try XCTUnwrap(frames.first)))
        XCTAssertEqual(reading.voltage, 15.59, accuracy: 0.000_001)
        XCTAssertEqual(reading.current, 0, accuracy: 0.000_001)
        XCTAssertEqual(reading.power, 0)
        XCTAssertEqual(reading.stateOfCharge, 100)
        XCTAssertEqual(reading.stateOfHealth, nil)
        XCTAssertEqual(reading.stateCode, 1)
        XCTAssertEqual(reading.capacityAh, 5.00, accuracy: 0.000_001)
        XCTAssertEqual(reading.remainingAh, 4.99, accuracy: 0.000_001)
        XCTAssertEqual(reading.temperatures, [22.6, 22.5, 22.1])
        XCTAssertEqual(reading.mosTemperature, 22.5)
        XCTAssertEqual(reading.protectionBits, 0)
        XCTAssertEqual(reading.hasAlarm, false)
        XCTAssertEqual(reading.cells.count, 4)
        XCTAssertNil(reading.cellDelta)
    }

    func testCellFrameCompletesTheSameReading() throws {
        var parser = JBDBMSProtocol()
        var assembler = JBDBMSAssembler()
        let first = try XCTUnwrap(parser.append(basic).first)
        _ = assembler.consume(first)
        let second = try XCTUnwrap(parser.append(cells).first)
        let reading = try XCTUnwrap(assembler.consume(second))
        XCTAssertEqual(reading.cells.count, 4)
        XCTAssertEqual(try XCTUnwrap(reading.cells[0]), 3.899, accuracy: 0.000_001)
        XCTAssertEqual(try XCTUnwrap(reading.cells[1]), 3.888, accuracy: 0.000_001)
        XCTAssertEqual(try XCTUnwrap(reading.cells[3]), 3.889, accuracy: 0.000_001)
        XCTAssertEqual(try XCTUnwrap(reading.cellDelta), 0.014, accuracy: 0.000_001)
        XCTAssertEqual(reading.voltage, 15.59, accuracy: 0.000_001)
    }

    func testEveryBLEFragmentBoundaryKeepsOneCycleIntact() {
        let stream = basic + cells
        for split in 0...stream.count {
            var parser = JBDBMSProtocol()
            var assembler = JBDBMSAssembler()
            var readings: [BMSReading] = []
            for piece in [stream.prefix(split), stream.dropFirst(split)] {
                for decoded in parser.append(Data(piece)) {
                    if let reading = assembler.consume(decoded) { readings.append(reading) }
                }
            }
            XCTAssertEqual(readings.count, 2, "split at \(split)")
            XCTAssertEqual(readings.last?.cells.count, 4, "split at \(split)")
        }
        var parser = JBDBMSProtocol()
        var assembler = JBDBMSAssembler()
        var readings: [BMSReading] = []
        for byte in stream {
            for decoded in parser.append(Data([byte])) {
                if let reading = assembler.consume(decoded) { readings.append(reading) }
            }
        }
        XCTAssertEqual(readings.count, 2)
    }

    func testCorruptChecksumNoiseAndConcatenatedFramesResynchronise() {
        var damaged = basic
        damaged[8] ^= 0x01
        var parser = JBDBMSProtocol()
        XCTAssertTrue(parser.append(damaged).isEmpty)

        parser = JBDBMSProtocol()
        let frames = parser.append(Data([0x00, 0xdd, 0xaa, 0x55]) + basic + cells)
        XCTAssertEqual(frames.count, 2)
        XCTAssertEqual(frames.first?.command, 0x03)
        XCTAssertEqual(frames.last?.command, 0x04)
    }

    func testRejectedStatusIsNeverPublished() {
        let rejected = frame(0x03, status: 0x01, payload: basicPayload(voltage: 82.78, current: 0,
            soc: 78, protection: 0, cellCount: 4, temperatures: [14]))
        var parser = JBDBMSProtocol()
        XCTAssertTrue(parser.append(rejected).isEmpty)
    }

    func testInvalidSocOrVoltageIsRejected() {
        let badSOC = frame(0x03, payload: basicPayload(voltage: 82.78, current: 0, soc: 101,
            protection: 0, cellCount: 4, temperatures: [14]))
        var parser = JBDBMSProtocol()
        var assembler = JBDBMSAssembler()
        for decoded in parser.append(badSOC) { XCTAssertNil(assembler.consume(decoded)) }

        let badVoltage = frame(0x03, payload: basicPayload(voltage: 0, current: 0, soc: 50,
            protection: 0, cellCount: 4, temperatures: [14]))
        parser = JBDBMSProtocol()
        for decoded in parser.append(badVoltage) { XCTAssertNil(assembler.consume(decoded)) }
    }

    func testChargingCurrentAndPower() throws {
        var parser = JBDBMSProtocol()
        var assembler = JBDBMSAssembler()
        let decoded = try XCTUnwrap(parser.append(frame(0x03, payload: basicPayload(voltage: 82.78,
            current: 12.34, soc: 78, protection: 0, cellCount: 4, temperatures: [14, 15]))).first)
        let reading = try XCTUnwrap(assembler.consume(decoded))
        XCTAssertEqual(reading.current, 12.34, accuracy: 0.000_001)
        XCTAssertEqual(reading.power, 1_022)
        XCTAssertEqual(reading.stateCode, 2)
        XCTAssertEqual(reading.stateOfHealth, nil)
        XCTAssertEqual(reading.temperatures.count, 2)
        XCTAssertEqual(reading.mosTemperature, 15)
    }

    func testDischargingCurrentIsSignedAndNegative() throws {
        var parser = JBDBMSProtocol()
        var assembler = JBDBMSAssembler()
        let decoded = try XCTUnwrap(parser.append(frame(0x03, payload: basicPayload(voltage: 82.78,
            current: -12.3, soc: 78, protection: 0, cellCount: 4, temperatures: [14]))).first)
        let reading = try XCTUnwrap(assembler.consume(decoded))
        XCTAssertEqual(reading.current, -12.3, accuracy: 0.000_001)
        XCTAssertEqual(reading.power, -1_018)
        XCTAssertEqual(reading.stateCode, 4)
    }

    func testProtectionBitsBecomeNamesAndAbnormalState() throws {
        var parser = JBDBMSProtocol()
        var assembler = JBDBMSAssembler()
        let decoded = try XCTUnwrap(parser.append(frame(0x03, payload: basicPayload(voltage: 82.78,
            current: 0, soc: 78, protection: 0x0009, cellCount: 4, temperatures: [14]))).first)
        let reading = try XCTUnwrap(assembler.consume(decoded))
        XCTAssertTrue(reading.hasAlarm)
        XCTAssertEqual(reading.stateCode, 5)
        XCTAssertEqual(reading.alarmBits, 0x0009)
        XCTAssertEqual(reading.protectionDescriptions, ["单体过压", "总压欠压"])
        XCTAssertEqual(reading.protectionBits, 9)
    }

    func testHundredMilliampUnitFlagScalesByTen() throws {
        var parser = JBDBMSProtocol()
        var assembler = JBDBMSAssembler()
        // mos 0x83 keeps both MOS bits on and sets bit 7, the 100 mA / 100 mAh unit.
        let decoded = try XCTUnwrap(parser.append(frame(0x03, payload: basicPayload(voltage: 82.78,
            current: 12.34, soc: 78, protection: 0, cellCount: 4, temperatures: [14],
            mos: 0x83))).first)
        let reading = try XCTUnwrap(assembler.consume(decoded))
        // The same raw words now mean 100 mA / 100 mAh instead of 10 mA / 10 mAh.
        XCTAssertEqual(reading.current, 123.4, accuracy: 0.000_001)
        XCTAssertEqual(reading.capacityAh, 1_700, accuracy: 0.000_001)
        XCTAssertEqual(reading.remainingAh, 1_319.2, accuracy: 0.000_001)
    }

    func testTenMillivoltCellReportIsScaledToo() throws {
        var parser = JBDBMSProtocol()
        var assembler = JBDBMSAssembler()
        _ = assembler.consume(try XCTUnwrap(parser.append(basic).first))
        // Older boards report 10 mV steps: 0x0147 = 327 → 3.27 V.
        let frame10mV = frame(0x04, payload: [0x01, 0x47, 0x01, 0x48])
        let reading = try XCTUnwrap(assembler.consume(try XCTUnwrap(parser.append(frame10mV).first)))
        XCTAssertEqual(reading.cells.count, 2)
        XCTAssertEqual(try XCTUnwrap(reading.cells[0]), 3.27, accuracy: 0.000_001)
        XCTAssertEqual(try XCTUnwrap(reading.cells[1]), 3.28, accuracy: 0.000_001)
    }

    func testAbsentCellFlagIsReportedAsUnknown() throws {
        var parser = JBDBMSProtocol()
        var assembler = JBDBMSAssembler()
        _ = assembler.consume(try XCTUnwrap(parser.append(basic).first))
        let reading = try XCTUnwrap(assembler.consume(try XCTUnwrap(
            parser.append(frame(0x04, payload: [0x0f, 0x3b, 0x00, 0x00])).first)))
        XCTAssertNotNil(reading.cells[0])
        XCTAssertNil(reading.cells[1])
        XCTAssertNil(reading.cellDelta)
    }

    func testSampleFreshnessUsesMonotonicAgeAndRejectsClockReversal() throws {
        var parser = JBDBMSProtocol()
        var assembler = JBDBMSAssembler()
        let reading = try XCTUnwrap(assembler.consume(try XCTUnwrap(parser.append(basic).first)))
        let sample = BMSSample(reading: reading, uptime: 100)
        XCTAssertTrue(sample.isFresh(at: 105))
        XCTAssertFalse(sample.isFresh(at: 105.001))
        XCTAssertFalse(sample.isFresh(at: 99))
    }

    func testNoiseBufferIsBoundedAndRecovers() {
        var parser = JBDBMSProtocol()
        XCTAssertTrue(parser.append(Data(repeating: 0xdd, count: 50_000)).isEmpty)
        XCTAssertLessThanOrEqual(parser.bufferedByteCount, JBDBMSProtocol.maximumBufferedBytes)
        // The framer must still find the next real frame after that noise.
        XCTAssertEqual(parser.append(basic).count, 1)
    }

    func testShortOrOddCellFramesAreIgnored() throws {
        var parser = JBDBMSProtocol()
        var assembler = JBDBMSAssembler()
        _ = assembler.consume(try XCTUnwrap(parser.append(basic).first))
        let odd = try XCTUnwrap(parser.append(frame(0x04, payload: [0x0f])).first)
        XCTAssertNil(assembler.consume(odd))
        let truncated = try XCTUnwrap(parser.append(frame(0x03, payload: [0x00, 0x01])).first)
        XCTAssertNil(assembler.consume(truncated))
    }
}
