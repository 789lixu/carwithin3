import CoreImage
import UIKit

/// Renders a small, noninteractive telemetry panel once per changed text. The
/// same bitmap is shown locally and composited into Ninebot's encoded video.
final class BMSOverlayPresenter {
    private let imageView = UIImageView()
    private var cachedText: String?
    private var cachedImage: CGImage?
    private var cachedConfiguration: BMSCardConfiguration?
    private var constraints: [NSLayoutConstraint] = []
    var onImage: ((CGImage?, BMSCardConfiguration) -> Void)?

    func attach(to surface: UIView) {
        imageView.isUserInteractionEnabled = false
        imageView.isAccessibilityElement = true
        imageView.accessibilityLabel = "电池实时信息"
        imageView.contentMode = .scaleAspectFit
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.isHidden = true
        surface.addSubview(imageView)
        cachedConfiguration = nil // Layout must be rebuilt even if telemetry arrived before attachment.
    }

    func update(enabled: Bool, reading: BMSReading?, status: String,
                configuration: BMSCardConfiguration) {
        guard enabled else {
            let wasVisible = !imageView.isHidden
            imageView.isHidden = true
            cachedText = nil; cachedImage = nil; cachedConfiguration = nil
            if wasVisible { onImage?(nil, configuration) }
            return
        }
        let text: String
        if let reading {
            text = configuration.lines(for: reading).joined(separator: "\n")
        } else {
            text = "JBD BMS · 无实时数据\n" + (status.contains("过期") || status.contains("断开") || status.contains("重连")
                ? "连接失联，等待恢复" : "等待电池数据")
        }
        let previousLineCount = cachedText?.components(separatedBy: "\n").count
        let lineCount = min(2, text.components(separatedBy: "\n").count)
        let styleChanged = cachedConfiguration?.backgroundOpacity != configuration.backgroundOpacity
            || cachedConfiguration?.textColorHex != configuration.textColorHex
        let changed = text != cachedText || cachedConfiguration != configuration || imageView.isHidden
        let needsLayout = previousLineCount != lineCount || cachedConfiguration != configuration
        if text != cachedText || styleChanged {
            cachedImage = Self.render(text, alarm: reading?.hasAlarm == true,
                                      opacity: configuration.backgroundOpacity,
                                      textColor: BMSThemeColor.color(hex: configuration.textColorHex))
            imageView.image = cachedImage.map { UIImage(cgImage: $0) }
            imageView.accessibilityValue = text.replacingOccurrences(of: "\n", with: "，")
        }
        cachedText = text; cachedConfiguration = configuration
        imageView.isHidden = false
        if let surface = imageView.superview, needsLayout {
            layout(on: surface, configuration: configuration, lineCount: lineCount)
        }
        if changed { onImage?(cachedImage, configuration) }
    }

    /// Used by settings only. A sample reading must never enter the live overlay.
    static func preview(_ reading: BMSReading, configuration: BMSCardConfiguration) -> CGImage? {
        render(configuration.lines(for: reading).joined(separator: "\n"),
               alarm: reading.hasAlarm, opacity: configuration.backgroundOpacity,
               textColor: BMSThemeColor.color(hex: configuration.textColorHex))
    }

    private func layout(on surface: UIView, configuration: BMSCardConfiguration, lineCount: Int) {
        NSLayoutConstraint.deactivate(constraints)
        // Free placement: the bar centre is pinned to a fraction of the video,
        // so a drag in the settings preview maps one-to-one onto the instrument.
        constraints = [
            NSLayoutConstraint(item: imageView, attribute: .width, relatedBy: .equal,
                               toItem: surface, attribute: .width,
                               multiplier: CGFloat(configuration.size.widthFraction), constant: 0),
            NSLayoutConstraint(item: imageView, attribute: .height, relatedBy: .equal,
                               toItem: imageView, attribute: .width,
                               multiplier: CGFloat(lineCount == 1 ? 72 : 122) / 640, constant: 0),
            NSLayoutConstraint(item: imageView, attribute: .centerX, relatedBy: .equal,
                               toItem: surface, attribute: .trailing,
                               multiplier: CGFloat(min(1, max(0, configuration.anchorX))), constant: 0),
            NSLayoutConstraint(item: imageView, attribute: .centerY, relatedBy: .equal,
                               toItem: surface, attribute: .bottom,
                               multiplier: CGFloat(min(1, max(0, configuration.anchorY))), constant: 0)
        ]
        NSLayoutConstraint.activate(constraints)
    }

    private static func render(_ text: String, alarm: Bool, opacity: Double, textColor: UIColor) -> CGImage? {
        let lineCount = min(2, text.components(separatedBy: "\n").count)
        let size = CGSize(width: 640, height: lineCount == 1 ? 72 : 122)
        let format = UIGraphicsImageRendererFormat()
        format.scale = 1
        return UIGraphicsImageRenderer(size: size, format: format).image { _ in
            UIColor.black.withAlphaComponent(min(1, max(0, opacity))).setFill()
            UIBezierPath(roundedRect: CGRect(origin: .zero, size: size), cornerRadius: 16).fill()
            let paragraph = NSMutableParagraphStyle()
            paragraph.lineBreakMode = .byTruncatingTail
            let color: UIColor = alarm ? .systemOrange : textColor
            for (index, line) in text.components(separatedBy: "\n").prefix(2).enumerated() {
                let baseFont = UIFont.monospacedDigitSystemFont(ofSize: 36, weight: .semibold)
                let width = (line as NSString).size(withAttributes: [.font: baseFont]).width
                let font = UIFont.monospacedDigitSystemFont(ofSize: min(36, max(14, 36 * 604 / max(1, width))), weight: .semibold)
                (line as NSString).draw(in: CGRect(x: 18, y: CGFloat(12 + index * 50), width: 604, height: 48), withAttributes: [
                    .font: font, .foregroundColor: color, .paragraphStyle: paragraph
                ])
            }
        }.cgImage
    }
}
