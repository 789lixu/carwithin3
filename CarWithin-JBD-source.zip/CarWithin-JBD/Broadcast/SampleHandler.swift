import ReplayKit
import CoreImage
import CoreGraphics
import ImageIO
import Network
import Foundation

/// 屏幕广播扩展：把 iPhone 的整屏画面压成小尺寸 JPEG，通过 127.0.0.1 的 TCP
/// 连接回传给主 App，由主 App 作为小窗叠加到九号仪表视频里。
/// 走回环 TCP 而不是 App Group：App Group 需要 provisioning profile 支持，
/// 本工程交付未签名 IPA 由 Esign 重签，拿不到 App Group 能力。
final class SampleHandler: RPBroadcastSampleHandler {
    private let queue = DispatchQueue(label: "carwithin.mirror.send")
    private let context = CIContext(options: [.useSoftwareRenderer: false])
    private let port: NWEndpoint.Port = 46123
    private var connection: NWConnection?
    private var lastSentAt: TimeInterval = 0
    private var lastAttemptAt: TimeInterval = 0

    private static let minimumInterval: TimeInterval = 0.2
    private static let maximumWidth: CGFloat = 480
    private static let jpegQuality: CGFloat = 0.6

    override func broadcastStarted(withSetupInfo setupInfo: [String: NSObject]?) {
        connectIfNeeded()
    }

    override func broadcastPaused() {}

    override func broadcastResumed() {
        connectIfNeeded()
    }

    override func broadcastFinished() {
        connection?.cancel()
        connection = nil
    }

    private func connectIfNeeded() {
        let now = ProcessInfo.processInfo.systemUptime
        guard connection == nil, now - lastAttemptAt >= 1 else { return }
        lastAttemptAt = now
        let candidate = NWConnection(host: NWEndpoint.Host("127.0.0.1"), port: port, using: .tcp)
        candidate.stateUpdateHandler = { [weak self] state in
            guard let self else { return }
            switch state {
            case .failed, .cancelled:
                self.queue.async {
                    if self.connection === candidate { self.connection = nil }
                }
            default:
                break
            }
        }
        candidate.start(queue: queue)
        connection = candidate
    }

    override func processSampleBuffer(_ sampleBuffer: CMSampleBuffer, with sampleBufferType: RPSampleBufferType) {
        guard sampleBufferType == .video else { return }
        let now = ProcessInfo.processInfo.systemUptime
        guard now - lastSentAt >= Self.minimumInterval else { return }
        lastSentAt = now
        guard let pixelBuffer = CMSampleBufferGetImageBuffer(sampleBuffer) else { return }

        let source = CIImage(cvPixelBuffer: pixelBuffer)
        let width = source.extent.width
        guard width > 1 else { return }
        let scale = min(1, Self.maximumWidth / width)
        let scaled = source.transformed(by: CGAffineTransform(scaleX: scale, y: scale))

        guard let image = context.createCGImage(scaled, from: scaled.extent) else { return }
        let payload = NSMutableData()
        guard let destination = CGImageDestinationCreateWithData(payload, "public.jpeg" as CFString, 1, nil) else { return }
        CGImageDestinationAddImage(destination, image, [kCGImageDestinationLossyCompressionQuality: Self.jpegQuality] as CFDictionary)
        guard CGImageDestinationFinalize(destination) else { return }

        send(payload as Data)
    }

    private func send(_ payload: Data) {
        connectIfNeeded()
        guard let connection else { return }
        var length = UInt32(payload.count).bigEndian
        let header = withUnsafeBytes(of: &length) { Data($0) }
        let message = header + payload
        connection.send(content: message, completion: .contentProcessed { [weak self] error in
            guard error != nil, let self else { return }
            self.queue.async {
                self.connection?.cancel()
                self.connection = nil
            }
        })
    }
}
