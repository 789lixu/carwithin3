import CoreGraphics
import Foundation
import ImageIO
import Network

/// 主 App 里的回环 TCP 服务端：接收屏幕广播扩展发来的 JPEG 帧。
/// 一帧 = 4 字节大端长度 + JPEG 数据，按顺序解码后回调到主线程。
final class ScreenMirrorServer {
    static let port: NWEndpoint.Port = 46123

    private let queue = DispatchQueue(label: "carwithin.mirror.receive")
    private var listener: NWListener?
    private var connection: NWConnection?
    private var buffer = Data()
    private var running = false

    /// 最近一帧的时间戳，用于判断画面是否还新鲜。
    private(set) var latestFrameAt: TimeInterval = 0
    var onImage: ((CGImage) -> Void)?

    func start() {
        guard !running else { return }
        running = true
        queue.async { [weak self] in self?.listen() }
    }

    func stop() {
        running = false
        queue.async { [weak self] in
            self?.connection?.cancel()
            self?.connection = nil
            self?.listener?.cancel()
            self?.listener = nil
            self?.buffer.removeAll()
        }
    }

    private func listen() {
        guard running, listener == nil else { return }
        do {
            let listener = try NWListener(using: .tcp, on: Self.port)
            listener.newConnectionHandler = { [weak self] newConnection in
                guard let self else { return }
                self.connection?.cancel()
                self.connection = newConnection
                self.buffer.removeAll()
                newConnection.start(queue: self.queue)
                self.receive(on: newConnection)
            }
            listener.stateUpdateHandler = { _ in }
            listener.start(queue: queue)
            self.listener = listener
        } catch {
            running = false
        }
    }

    private func receive(on connection: NWConnection) {
        connection.receive(minimumIncompleteLength: 1, maximumLength: 128 * 1024) { [weak self] data, _, isComplete, error in
            guard let self else { return }
            if let data, !data.isEmpty { self.append(data) }
            if error != nil || isComplete {
                self.connection = nil
                connection.cancel()
                return
            }
            self.receive(on: connection)
        }
    }

    private func append(_ data: Data) {
        buffer.append(data)
        while buffer.count >= 4 {
            let prefix = [UInt8](buffer.prefix(4))
            let length = Int(prefix[0]) << 24 | Int(prefix[1]) << 16 | Int(prefix[2]) << 8 | Int(prefix[3])
            guard length > 8, length <= 512 * 1024 else { buffer.removeAll(); return }
            guard buffer.count >= 4 + length else { return }
            let start = buffer.index(buffer.startIndex, offsetBy: 4)
            let end = buffer.index(start, offsetBy: length)
            let payload = Data(buffer[start..<end])
            buffer.removeFirst(4 + length)
            decode(payload)
        }
    }

    private func decode(_ payload: Data) {
        guard let source = CGImageSourceCreateWithData(payload as CFData, nil),
              let image = CGImageSourceCreateImageAtIndex(source, 0, nil) else { return }
        latestFrameAt = ProcessInfo.processInfo.systemUptime
        DispatchQueue.main.async { [weak self] in self?.onImage?(image) }
    }
}
