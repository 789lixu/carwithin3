import CoreGraphics
import UIKit

/// 小窗所在的角。
enum MirrorCorner: Int, CaseIterable {
    case bottomRight
    case bottomLeft
    case topRight
    case topLeft

    var isLeft: Bool { self == .bottomLeft || self == .topLeft }
    var isTop: Bool { self == .topRight || self == .topLeft }

    var title: String {
        switch self {
        case .bottomRight: return "右下角"
        case .bottomLeft: return "左下角"
        case .topRight: return "右上角"
        case .topLeft: return "左上角"
        }
    }
}

/// 小窗的显示参数：开关、大小、位置。手机本地小窗与推给仪表的画面共用同一份。
struct MirrorConfiguration {
    var enabled = true
    var widthFraction: CGFloat = 0.34
    var corner: MirrorCorner = .bottomRight
}

/// 屏幕镜像小窗：同一份参数既用于手机本地预览，也传给九号输出用来合成进编码画面。
/// 长按小窗可弹出菜单：隐藏/显示、换大小、换位置。隐藏后右下角留一个小按钮可恢复。
final class MirrorOverlayPresenter {
    static let widthFractions: [CGFloat] = [0.25, 0.34, 0.45]
    static let sizeTitles = ["小", "中", "大"]

    private enum Key {
        static let enabled = "mirror.overlay.enabled"
        static let width = "mirror.overlay.widthFraction"
        static let corner = "mirror.overlay.corner"
    }

    private(set) var configuration = MirrorConfiguration()
    var onImage: ((CGImage?, MirrorConfiguration) -> Void)?
    var onMenuRequested: (() -> Void)?

    let view = UIImageView()
    let restoreButton = UIButton(type: .system)

    private weak var surface: UIView?
    private var currentImage: CGImage?
    private var widthConstraint: NSLayoutConstraint!
    private var heightConstraint: NSLayoutConstraint!
    private var xConstraint: NSLayoutConstraint?
    private var yConstraint: NSLayoutConstraint?

    init() {
        let defaults = UserDefaults.standard
        if defaults.object(forKey: Key.enabled) != nil {
            configuration.enabled = defaults.bool(forKey: Key.enabled)
        }
        if defaults.object(forKey: Key.width) != nil {
            let value = CGFloat(defaults.double(forKey: Key.width))
            if Self.widthFractions.contains(where: { abs($0 - value) < 0.001 }) {
                configuration.widthFraction = value
            }
        }
        if defaults.object(forKey: Key.corner) != nil {
            configuration.corner = MirrorCorner(rawValue: defaults.integer(forKey: Key.corner)) ?? .bottomRight
        }
    }

    func attach(to surface: UIView) {
        self.surface = surface

        view.isUserInteractionEnabled = true
        view.clipsToBounds = true
        view.contentMode = .scaleAspectFit
        view.backgroundColor = UIColor.black.withAlphaComponent(0.85)
        view.layer.cornerRadius = 6
        view.translatesAutoresizingMaskIntoConstraints = false
        view.isHidden = true
        surface.addSubview(view)

        widthConstraint = view.widthAnchor.constraint(equalToConstant: 120)
        heightConstraint = view.heightAnchor.constraint(equalToConstant: 200)
        widthConstraint.isActive = true
        heightConstraint.isActive = true
        applyCornerAnchors()

        restoreButton.translatesAutoresizingMaskIntoConstraints = false
        restoreButton.setTitle("屏", for: .normal)
        restoreButton.setTitleColor(.white, for: .normal)
        restoreButton.titleLabel?.font = .systemFont(ofSize: 13, weight: .semibold)
        restoreButton.backgroundColor = UIColor.black.withAlphaComponent(0.45)
        restoreButton.layer.cornerRadius = 8
        restoreButton.isHidden = true
        restoreButton.addTarget(self, action: #selector(toggleVisible), for: .touchUpInside)
        surface.addSubview(restoreButton)
        NSLayoutConstraint.activate([
            restoreButton.widthAnchor.constraint(equalToConstant: 44),
            restoreButton.heightAnchor.constraint(equalToConstant: 32),
            restoreButton.trailingAnchor.constraint(equalTo: surface.trailingAnchor, constant: -8),
            restoreButton.bottomAnchor.constraint(equalTo: surface.bottomAnchor, constant: -8)
        ])

        let press = UILongPressGestureRecognizer(target: self, action: #selector(handleLongPress))
        press.minimumPressDuration = 0.5
        view.addGestureRecognizer(press)

        layoutWindow()
        publish()
    }

    func update(_ image: CGImage?) {
        currentImage = image
        layoutWindow()
        publish()
    }

    // MARK: - 菜单动作

    @objc private func handleLongPress() {
        onMenuRequested?()
    }

    @objc func toggleVisible() {
        configuration.enabled.toggle()
        layoutWindow()
        publish()
        persist()
    }

    func setSize(index: Int) {
        let clamped = max(0, min(Self.widthFractions.count - 1, index))
        configuration.widthFraction = Self.widthFractions[clamped]
        layoutWindow()
        publish()
        persist()
    }

    func setCorner(_ corner: MirrorCorner) {
        configuration.corner = corner
        applyCornerAnchors()
        layoutWindow()
        publish()
        persist()
    }

    var sizeIndex: Int {
        Self.widthFractions.firstIndex(where: { abs($0 - configuration.widthFraction) < 0.001 }) ?? 1
    }

    // MARK: - 内部

    private func applyCornerAnchors() {
        xConstraint?.isActive = false
        yConstraint?.isActive = false
        guard let surface else { return }
        switch configuration.corner {
        case .bottomRight:
            xConstraint = view.trailingAnchor.constraint(equalTo: surface.trailingAnchor, constant: -8)
            yConstraint = view.bottomAnchor.constraint(equalTo: surface.bottomAnchor, constant: -8)
        case .bottomLeft:
            xConstraint = view.leadingAnchor.constraint(equalTo: surface.leadingAnchor, constant: 8)
            yConstraint = view.bottomAnchor.constraint(equalTo: surface.bottomAnchor, constant: -8)
        case .topRight:
            xConstraint = view.trailingAnchor.constraint(equalTo: surface.trailingAnchor, constant: -8)
            yConstraint = view.topAnchor.constraint(equalTo: surface.topAnchor, constant: 8)
        case .topLeft:
            xConstraint = view.leadingAnchor.constraint(equalTo: surface.leadingAnchor, constant: 8)
            yConstraint = view.topAnchor.constraint(equalTo: surface.topAnchor, constant: 8)
        }
        xConstraint?.isActive = true
        yConstraint?.isActive = true
    }

    /// 按当前参数算尺寸：宽度按比例，高度按画面原始比例，过高时自动缩到视口 90% 以内。
    private func layoutWindow() {
        guard let surface else { return }
        let hasImage = currentImage != nil
        view.isHidden = !(hasImage && configuration.enabled)
        restoreButton.isHidden = !(hasImage && !configuration.enabled)
        guard hasImage, let image = currentImage else { return }

        let bounds = surface.bounds
        guard bounds.width > 1, bounds.height > 1 else { return }
        let aspect = CGFloat(image.height) / CGFloat(max(1, image.width))
        var width = bounds.width * configuration.widthFraction
        var height = width * aspect
        let maxHeight = bounds.height * 0.9
        if height > maxHeight {
            height = maxHeight
            width = height / aspect
        }
        widthConstraint.constant = width
        heightConstraint.constant = height
        view.image = UIImage(cgImage: image)
    }

    private func publish() {
        let image = configuration.enabled ? currentImage : nil
        onImage?(image, configuration)
    }

    private func persist() {
        let defaults = UserDefaults.standard
        defaults.set(configuration.enabled, forKey: Key.enabled)
        defaults.set(Double(configuration.widthFraction), forKey: Key.width)
        defaults.set(configuration.corner.rawValue, forKey: Key.corner)
    }
}
