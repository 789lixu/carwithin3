import UIKit
import CoreGraphics

/// Owns 嘉佰达 (JBD) telemetry and settings independently of CarPlay connection
/// configuration. CoreBluetooth callbacks and all UI work stay on the main queue.
final class JBDBMSController: NSObject {
    var onImage: ((CGImage?, BMSCardConfiguration) -> Void)?
    var onLog: ((String) -> Void)?
    var aspectRatio: CGFloat = 848 / 480 { didSet { if aspectRatio != oldValue { refreshBMS() } } }
    private weak var rootPage: SettingsPageController?
    private var lastSelectedID: UUID?
    private let bmsClient = JBDBMSClient()
    private let bmsOverlay = BMSOverlayPresenter()
    private let bmsEnabledSwitch = UISwitch()
    private let bmsPosition = ChoiceMenu(items: BMSCardConfiguration.Position.allCases.map(\.title))
    private let bmsCardSize = ChoiceMenu(items: BMSCardConfiguration.Size.allCases.map(\.title))
    private let bmsCardBackground = ChoiceMenu(items: BMSCardConfiguration.Background.allCases.map(\.title))
    private var bmsCardConfiguration = BMSCardConfiguration()
    private var bmsFieldSwitches: [BMSCardConfiguration.Field: UISwitch] = [:]
    private let bmsCardPreview = BMSCardPreviewView()
    private let bmsCardPreviewStatus = StatusLabel()
    private let bmsCardOpacity = UISlider()
    private let bmsCardOpacityValue = UILabel()
    private let bmsColorDelegate = BMSColorPickerDelegate()
    private let bmsLockSwitch = UISwitch()
    private let bmsPollMenu = ChoiceMenu(items: JBDBMSController.pollIntervalTitles)
    private let bmsLayoutMenu = ChoiceMenu(items: BMSCardConfiguration.Layout.allCases.map(\.title))
    private let bmsPanelWidthMenu = ChoiceMenu(items: JBDBMSController.panelWidthTitles)
    /// The panel is a full-height strip on the right edge; 25% lines up with the
    /// vehicle strip that already carries the P card.
    static let panelWidthTitles = ["窄 22%", "标准 25%", "宽 28%"]
    static let panelWidthValues: [Double] = [0.22, 0.25, 0.28]
    private var panelWidthIndex: Int {
        let stored = UserDefaults.standard.object(forKey: "jbdBMSPanelWidth") as? Double
        guard let stored else { return 1 }
        return Self.panelWidthValues.firstIndex(where: { abs($0 - stored) < 0.02 }) ?? 1
    }
    private let bmsChargingSwitch = UISwitch()
    private let bmsForceChargingSwitch = UISwitch()
    private enum ColorTarget { case text, bar, track, data }
    private var colorTarget: ColorTarget = .text
    private var wallpaperPicker: UIImagePickerController?
    static let pollIntervalTitles = ["1 秒（最快）", "2 秒（均衡）", "3 秒（远距离）"]
    static let pollIntervalValues: [TimeInterval] = [1, 2, 3]
    private var pollIntervalIndex: Int {
        let stored = UserDefaults.standard.double(forKey: "jbdBMSPollInterval")
        return Self.pollIntervalValues.firstIndex(where: { abs($0 - stored) < 0.4 }) ?? 0
    }
    private let bmsStatus = StatusLabel()
    private let bmsDetails = StatusLabel()
    private let bmsLiveSummary = BMSLiveSummaryView()
    private var bmsDeviceList: [UUID] = []

    override init() {
        super.init()
        configureBMS()
    }

    func attach(to surface: UIView) {
        bmsOverlay.attach(to: surface)
        refreshBMS()
    }

    private func page(_ title: String, _ build: @escaping () -> [SettingsSection]) -> SettingsPageController {
        SettingsPageController(title: title, build: build)
    }
    private func reloadVisibleSettings() {
        (rootPage?.navigationController?.topViewController as? SettingsPageController)?.reload()
    }
    private func alert(_ title: String, _ message: String) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "好", style: .default))
        let presenter: UIViewController? = rootPage?.navigationController ?? rootPage
        presenter?.present(alert, animated: true)
    }

    private func configureBMS() {
        JBDBMSClient.migrateLegacyDefaults()
        bmsEnabledSwitch.isOn = UserDefaults.standard.bool(forKey: "jbdBMSEnabled")
        bmsEnabledSwitch.addTarget(self, action: #selector(bmsSettingsChanged), for: .valueChanged)
        bmsPosition.addTarget(self, action: #selector(bmsCardAppearanceChanged), for: .valueChanged)
        bmsCardBackground.addTarget(self, action: #selector(bmsCardAppearanceChanged), for: .valueChanged)
        let panelWidth = Self.panelWidthValues[panelWidthIndex]
        bmsCardConfiguration = BMSCardConfiguration(
            savedFields: UserDefaults.standard.stringArray(forKey: "jbdBMSCardFields"),
            sizeRawValue: UserDefaults.standard.object(forKey: "jbdBMSCardSize") as? Int,
            positionRawValue: UserDefaults.standard.object(forKey: "jbdBMSPosition") as? Int,
            backgroundRawValue: UserDefaults.standard.object(forKey: "jbdBMSCardBackground") as? Int,
            textColorHex: UserDefaults.standard.string(forKey: "jbdBMSCardTextColor"),
            backgroundOpacity: UserDefaults.standard.object(forKey: "jbdBMSCardOpacity") as? Double,
            anchorX: UserDefaults.standard.object(forKey: "jbdBMSCardAnchorX") as? Double,
            anchorY: UserDefaults.standard.object(forKey: "jbdBMSCardAnchorY") as? Double,
            layoutRawValue: UserDefaults.standard.object(forKey: "jbdBMSCardLayout") as? Int,
            barColorHex: UserDefaults.standard.string(forKey: "jbdBMSBarColor"),
            barTrackColorHex: UserDefaults.standard.string(forKey: "jbdBMSBarTrackColor"),
            dataColorHex: UserDefaults.standard.string(forKey: "jbdBMSDataColor"),
            wallpaperEnabled: UserDefaults.standard.bool(forKey: "jbdBMSWallpaperEnabled")
                && BMSWallpaperStore.isAvailable,
            chargingAnimation: UserDefaults.standard.object(forKey: "jbdBMSChargingAnimation") as? Bool ?? true,
            forceChargingAnimation: UserDefaults.standard.bool(forKey: "jbdBMSForceCharging"),
            panelWidthFraction: panelWidth)
        bmsLockSwitch.isOn = UserDefaults.standard.bool(forKey: "jbdBMSCardLocked")
        bmsLockSwitch.addTarget(self, action: #selector(bmsCardLockChanged), for: .valueChanged)
        bmsCardPreview.isDragEnabled = !bmsLockSwitch.isOn
        bmsCardPreview.onDrag = { [weak self] x, y in
            guard let self else { return }
            self.bmsCardConfiguration.anchorX = x
            self.bmsCardConfiguration.anchorY = y
            self.persistBMSCardConfiguration()
        }
        bmsCardSize.selectedSegmentIndex = bmsCardConfiguration.size.rawValue
        bmsCardOpacity.minimumValue = 0
        bmsCardOpacity.maximumValue = 1
        bmsCardOpacity.value = Float(bmsCardConfiguration.backgroundOpacity)
        bmsCardOpacity.addTarget(self, action: #selector(bmsCardOpacityChanged), for: .valueChanged)
        bmsCardOpacityValue.font = .monospacedDigitSystemFont(ofSize: 15, weight: .regular)
        bmsCardOpacityValue.textColor = .secondaryLabel
        bmsCardOpacityValue.text = Self.percentText(bmsCardConfiguration.backgroundOpacity)
        bmsCardOpacityValue.setContentHuggingPriority(.required, for: .horizontal)
        bmsCardOpacityValue.widthAnchor.constraint(equalToConstant: 48).isActive = true
        bmsColorDelegate.onPick = { [weak self] color in
            guard let self else { return }
            let hex = BMSThemeColor.hex(color)
            switch self.colorTarget {
            case .text: self.bmsCardConfiguration.textColorHex = hex
            case .bar: self.bmsCardConfiguration.barColorHex = hex
            case .track: self.bmsCardConfiguration.barTrackColorHex = hex
            case .data: self.bmsCardConfiguration.dataColorHex = hex
            }
            self.persistBMSCardConfiguration()
        }
        bmsPollMenu.selectedSegmentIndex = pollIntervalIndex
        bmsClient.pollInterval = Self.pollIntervalValues[pollIntervalIndex]
        bmsPollMenu.addTarget(self, action: #selector(bmsPollChanged), for: .valueChanged)
        bmsLayoutMenu.selectedSegmentIndex = bmsCardConfiguration.layout.rawValue
        bmsPanelWidthMenu.selectedSegmentIndex = panelWidthIndex
        bmsPanelWidthMenu.addTarget(self, action: #selector(bmsPanelWidthChanged), for: .valueChanged)
        bmsLayoutMenu.addTarget(self, action: #selector(bmsCardLayoutChanged), for: .valueChanged)
        bmsChargingSwitch.isOn = bmsCardConfiguration.chargingAnimation
        bmsChargingSwitch.addAction(UIAction { [weak self] action in
            guard let self, let control = action.sender as? UISwitch else { return }
            self.bmsCardConfiguration.chargingAnimation = control.isOn
            self.persistBMSCardConfiguration()
        }, for: .valueChanged)
        bmsForceChargingSwitch.isOn = bmsCardConfiguration.forceChargingAnimation
        bmsForceChargingSwitch.addAction(UIAction { [weak self] action in
            guard let self, let control = action.sender as? UISwitch else { return }
            self.bmsCardConfiguration.forceChargingAnimation = control.isOn
            self.persistBMSCardConfiguration()
        }, for: .valueChanged)
        bmsPosition.selectedSegmentIndex = bmsCardConfiguration.position.rawValue
        bmsCardBackground.selectedSegmentIndex = bmsCardConfiguration.background.rawValue
        bmsCardSize.addTarget(self, action: #selector(bmsCardSizeChanged), for: .valueChanged)
        for field in BMSCardConfiguration.Field.allCases {
            let control = UISwitch()
            control.isOn = bmsCardConfiguration.fields.contains(field)
            control.addAction(UIAction { [weak self, weak control] _ in
                guard let self, let control else { return }
                guard self.bmsCardConfiguration.set(field, visible: control.isOn) else {
                    control.setOn(true, animated: true)
                    self.alert("至少显示一项", "如需隐藏整张卡片，请关闭「读取并显示 BMS」。")
                    return
                }
                self.saveBMSCardConfiguration()
            }, for: .valueChanged)
            bmsFieldSwitches[field] = control
        }
        bmsDetails.numberOfLines = 0
        bmsDetails.font = .monospacedDigitSystemFont(ofSize: 14, weight: .regular)
        bmsOverlay.onImage = { [weak self] image, configuration in
            self?.onImage?(image, configuration)
        }
        bmsClient.onLog = { [weak self] message in self?.onLog?("BMS：" + message) }
        bmsClient.onChange = { [weak self] in self?.refreshBMS() }
        if bmsEnabledSwitch.isOn { bmsClient.start() }
        refreshBMS()
    }

    @objc private func bmsSettingsChanged() {
        UserDefaults.standard.set(bmsEnabledSwitch.isOn, forKey: "jbdBMSEnabled")
        if bmsEnabledSwitch.isOn { bmsClient.start() } else { bmsClient.stop() }
        refreshBMS()
        reloadVisibleSettings()
    }

    @objc private func bmsPollChanged() {
        let index = bmsPollMenu.selectedSegmentIndex
        guard Self.pollIntervalValues.indices.contains(index) else { return }
        let value = Self.pollIntervalValues[index]
        UserDefaults.standard.set(value, forKey: "jbdBMSPollInterval")
        bmsClient.pollInterval = value
        refreshBMS()
    }

    @objc private func bmsPanelWidthChanged() {
        let index = bmsPanelWidthMenu.selectedSegmentIndex
        guard Self.panelWidthValues.indices.contains(index) else { return }
        bmsCardConfiguration.panelWidthFraction = Self.panelWidthValues[index]
        saveBMSCardConfiguration()
    }

    @objc private func bmsCardLayoutChanged() {
        bmsCardConfiguration.layout = BMSCardConfiguration.Layout(rawValue: bmsLayoutMenu.selectedSegmentIndex) ?? .bar
        saveBMSCardConfiguration()
    }

    private func openColorPicker(_ target: ColorTarget) {
        colorTarget = target
        let current: String
        switch target {
        case .text: current = bmsCardConfiguration.textColorHex
        case .bar: current = bmsCardConfiguration.barColorHex
        case .track: current = bmsCardConfiguration.barTrackColorHex
        case .data: current = bmsCardConfiguration.dataColorHex
        }
        let picker = UIColorPickerViewController()
        picker.selectedColor = BMSThemeColor.color(hex: current)
        picker.supportsAlpha = false
        picker.delegate = bmsColorDelegate
        (rootPage?.navigationController ?? rootPage)?.present(picker, animated: true)
    }

    private func chooseWallpaper() {
        guard UIImagePickerController.isSourceTypeAvailable(.photoLibrary) else {
            alert("无法打开相册", "这台设备不允许访问照片图库。"); return
        }
        let picker = UIImagePickerController()
        picker.sourceType = .photoLibrary
        picker.delegate = self
        wallpaperPicker = picker
        (rootPage?.navigationController ?? rootPage)?.present(picker, animated: true)
    }

    private func clearWallpaper() {
        BMSWallpaperStore.clear()
        bmsCardConfiguration.wallpaperEnabled = false
        saveBMSCardConfiguration()
    }

    @objc private func bmsCardSizeChanged() {
        bmsCardConfiguration.size = BMSCardConfiguration.Size(rawValue: bmsCardSize.selectedSegmentIndex) ?? .medium
        saveBMSCardConfiguration()
    }

    @objc private func bmsCardAppearanceChanged() {
        bmsCardConfiguration.position = BMSCardConfiguration.Position(rawValue: bmsPosition.selectedSegmentIndex) ?? .topRight
        bmsCardConfiguration.anchorX = bmsCardConfiguration.position.isAtRight ? 0.82 : 0.18
        bmsCardConfiguration.anchorY = bmsCardConfiguration.position.isAtTop ? 0.12 : 0.88
        bmsCardConfiguration.background = BMSCardConfiguration.Background(rawValue: bmsCardBackground.selectedSegmentIndex) ?? .standard
        saveBMSCardConfiguration()
    }

    /// Writes preferences and repaints the card, without rebuilding an open
    /// settings table (a live slider drag must not be interrupted).
    private func persistBMSCardConfiguration() {
        UserDefaults.standard.set(bmsCardConfiguration.fields.map(\.rawValue), forKey: "jbdBMSCardFields")
        UserDefaults.standard.set(bmsCardConfiguration.size.rawValue, forKey: "jbdBMSCardSize")
        UserDefaults.standard.set(bmsCardConfiguration.position.rawValue, forKey: "jbdBMSPosition")
        UserDefaults.standard.set(bmsCardConfiguration.background.rawValue, forKey: "jbdBMSCardBackground")
        UserDefaults.standard.set(bmsCardConfiguration.textColorHex, forKey: "jbdBMSCardTextColor")
        UserDefaults.standard.set(bmsCardConfiguration.backgroundOpacity, forKey: "jbdBMSCardOpacity")
        UserDefaults.standard.set(bmsCardConfiguration.anchorX, forKey: "jbdBMSCardAnchorX")
        UserDefaults.standard.set(bmsCardConfiguration.anchorY, forKey: "jbdBMSCardAnchorY")
        UserDefaults.standard.set(bmsCardConfiguration.layout.rawValue, forKey: "jbdBMSCardLayout")
        UserDefaults.standard.set(bmsCardConfiguration.barColorHex, forKey: "jbdBMSBarColor")
        UserDefaults.standard.set(bmsCardConfiguration.barTrackColorHex, forKey: "jbdBMSBarTrackColor")
        UserDefaults.standard.set(bmsCardConfiguration.dataColorHex, forKey: "jbdBMSDataColor")
        UserDefaults.standard.set(bmsCardConfiguration.wallpaperEnabled, forKey: "jbdBMSWallpaperEnabled")
        UserDefaults.standard.set(bmsCardConfiguration.chargingAnimation, forKey: "jbdBMSChargingAnimation")
        UserDefaults.standard.set(bmsCardConfiguration.forceChargingAnimation, forKey: "jbdBMSForceCharging")
        UserDefaults.standard.set(bmsCardConfiguration.panelWidthFraction, forKey: "jbdBMSPanelWidth")
        refreshBMS()
    }

    private func saveBMSCardConfiguration() {
        persistBMSCardConfiguration()
        reloadVisibleSettings()
    }

    @objc private func bmsCardLockChanged() {
        UserDefaults.standard.set(bmsLockSwitch.isOn, forKey: "jbdBMSCardLocked")
        bmsCardPreview.isDragEnabled = !bmsLockSwitch.isOn
        // Keep the current position: rebuilding the page here used to look like
        // the card jumping back to a corner.
    }

    @objc private func bmsCardOpacityChanged() {
        bmsCardConfiguration.backgroundOpacity = Double(bmsCardOpacity.value)
        bmsCardOpacityValue.text = Self.percentText(bmsCardConfiguration.backgroundOpacity)
        persistBMSCardConfiguration()
    }

    private static func percentText(_ value: Double) -> String {
        String(format: "%.0f%%", min(1, max(0, value)) * 100)
    }

    private func opacityControlRow() -> UIView {
        let row = UIStackView(arrangedSubviews: [bmsCardOpacity, bmsCardOpacityValue])
        row.spacing = 10
        row.alignment = .center
        row.heightAnchor.constraint(greaterThanOrEqualToConstant: 32).isActive = true
        return row
    }

    /// MOS control is only offered for a pack that is sitting idle: a live
    /// discharge must never be interrupted from the phone.
    private var isPackIdle: Bool {
        guard let reading = bmsClient.freshReading else { return false }
        return abs(reading.current) < 0.5
    }

    private func confirmMOS(_ enabled: Bool) {
        guard bmsEnabledSwitch.isOn, bmsClient.freshReading != nil else {
            alert("还没有实时数据", "先让电池连上并读到有效数据，再来做停放断电。")
            return
        }
        guard isPackIdle else {
            alert("电池正在放电", "电流不为 0 时保护板会拒绝关闭放电，也不会让它生效。请先把车停稳、关掉所有用电设备再操作。")
            return
        }
        let message = enabled
            ? "将重新打开放电。操作后电池恢复对外供电。"
            : "将关闭放电，电池停止对外输出。\n\n只在停车停放时使用；起步前务必先点「开启放电」恢复。\n\n保护板在放电中会拒绝此命令，但请仍然按停放状态操作。"
        let alert = UIAlertController(title: enabled ? "开启放电" : "关闭放电", message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "取消", style: .cancel))
        alert.addAction(UIAlertAction(title: enabled ? "确认开启" : "确认关闭", style: .destructive) { [weak self] _ in
            guard let self else { return }
            let sent = self.bmsClient.requestDischarge(enabled)
            self.onLog?(sent ? "BMS：MOS 命令已发送" : "BMS：MOS 命令未发出（连接已断开）")
            DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) { [weak self] in
                self?.refreshBMS()
                self?.reloadVisibleSettings()
            }
        })
        let presenter: UIViewController? = rootPage?.navigationController ?? rootPage
        presenter?.present(alert, animated: true)
    }

    private func openTextColorPicker() { openColorPicker(.text) }

    private func applyBMSCardPreset(_ fields: [BMSCardConfiguration.Field]) {
        bmsCardConfiguration = BMSCardConfiguration(savedFields: fields.map(\.rawValue),
            sizeRawValue: bmsCardConfiguration.size.rawValue,
            positionRawValue: bmsCardConfiguration.position.rawValue,
            backgroundRawValue: bmsCardConfiguration.background.rawValue,
            textColorHex: bmsCardConfiguration.textColorHex,
            backgroundOpacity: bmsCardConfiguration.backgroundOpacity,
            anchorX: bmsCardConfiguration.anchorX,
            anchorY: bmsCardConfiguration.anchorY,
            layoutRawValue: bmsCardConfiguration.layout.rawValue,
            barColorHex: bmsCardConfiguration.barColorHex,
            barTrackColorHex: bmsCardConfiguration.barTrackColorHex,
            dataColorHex: bmsCardConfiguration.dataColorHex,
            wallpaperEnabled: bmsCardConfiguration.wallpaperEnabled,
            chargingAnimation: bmsCardConfiguration.chargingAnimation,
            forceChargingAnimation: bmsCardConfiguration.forceChargingAnimation,
            panelWidthFraction: bmsCardConfiguration.panelWidthFraction)
        for (field, control) in bmsFieldSwitches { control.isOn = bmsCardConfiguration.fields.contains(field) }
        saveBMSCardConfiguration()
    }

    private func refreshBMS() {
        let reading = bmsClient.freshReading
        bmsStatus.text = bmsEnabledSwitch.isOn ? bmsClient.status : "BMS 显示已关闭"
        bmsLiveSummary.update(reading)
        if let reading {
            let temperature = reading.maximumTemperature.map { String(format: "%.0f°C", $0) } ?? "--"
            let mos = reading.mosTemperature.map { String(format: "%.0f°C", $0) } ?? "--"
            let delta = reading.cellDelta.map { String(format: "%.0f mV", $0 * 1000) } ?? "--"
            let states = [0: "无状态", 1: "静止", 2: "充电", 3: "待机", 4: "放电", 5: "异常"]
            let protections = reading.protectionDescriptions
            bmsDetails.text = String(format: "电量 %d%% · %.2f V · %+.2f A · %d W\n剩余 %.2f / %.2f Ah\n最高温度 %@ · MOS %@\n%d 串 · 单体压差 %@\n状态：%@\n保护：0x%llX %@",
                reading.stateOfCharge, reading.voltage, reading.current, reading.power,
                reading.remainingAh, reading.capacityAh, temperature, mos, reading.cells.count, delta,
                states[reading.stateCode] ?? "未知", reading.protectionBits,
                protections.isEmpty ? "正常" : protections.joined(separator: "、"))
        } else {
            bmsDetails.text = "电量 -- · 电压 -- · 电流 -- · 功率 --\n等待校验有效的 JBD 实时数据。"
        }
        bmsOverlay.update(enabled: bmsEnabledSwitch.isOn, reading: reading, status: bmsClient.status,
                          configuration: bmsCardConfiguration)
        bmsCardPreview.update(reading: reading, configuration: bmsCardConfiguration,
                             aspectRatio: aspectRatio)
        bmsCardPreviewStatus.text = reading == nil ? "示例数据 · 当前没有实时读数" : "实时数据 · 当前连接的嘉佰达 JBD BMS"
        let ids = bmsClient.devices.map(\.id)
        if ids != bmsDeviceList || bmsClient.selectedID != lastSelectedID {
            lastSelectedID = bmsClient.selectedID
            bmsDeviceList = ids
            reloadVisibleSettings()
        }
    }
    func settingsPage() -> SettingsPageController {
        let root = page("电池与 BMS") { [unowned self] in
            [SettingsSection("嘉佰达 JBD BMS", footer: "「刷新间隔」拉长到 2–3 秒可显著减少空中的数据包，蓝牙信号弱、容易掉线时更稳；代价是仪表上的数字更新变慢。", [
                .control("读取并显示 BMS", self.bmsEnabledSwitch),
                .control("刷新间隔", self.bmsPollMenu),
                .note(self.bmsStatus),
                .page("连接设备", icon: ("antenna.radiowaves.left.and.right", .systemBlue), detail: { [unowned self] in
                    self.bmsClient.selectedName
                }) { [unowned self] in self.bmsDevicesPage() },
                .action("协议抓包（调试）", icon: ("waveform.path.ecg", .systemOrange)) { [unowned self] in
                    self.openSniffer()
                }
            ]),
            SettingsSection("实时电池", footer: "只显示最近 5 秒内的有效数据，断开后自动清空旧值。", [.view(self.bmsLiveSummary)]),
            SettingsSection("卡片与详情", [
                .page("卡片显示", icon: ("rectangle.topthird.inset.filled", .systemBlue), detail: { [unowned self] in
                    "\(self.bmsCardConfiguration.fields.count) 项 · \(self.bmsCardConfiguration.size.title)号"
                }) { [unowned self] in self.bmsCardPage() },
                .page("停放断电（实验）", icon: ("power", .systemRed), detail: { [unowned self] in
                    self.isPackIdle ? "电池静止，可操作" : "放电中，不可操作"
                }) { [unowned self] in self.mosPage() },
                .page("电池详情", icon: ("list.bullet.rectangle", .systemGray)) { [unowned self] in
                    self.page("电池详情") { [unowned self] in
                        [SettingsSection("实时参数", footer: "电流为保护板上报值：充电为正、放电为负。容量、温度、串数与保护状态均由 JBD 0x03 帧上报。", [.note(self.bmsDetails)])]
                    }
                }
            ])]
        }
        rootPage = root
        return root
    }

    private func bmsDevicesPage() -> SettingsPageController {
        page("BMS 连接设备") { [unowned self] in
            var sections = [SettingsSection("当前设备", [
                .info("已记住的设备", self.bmsClient.selectedName),
                .note(self.bmsStatus)
            ])]
            guard self.bmsEnabledSwitch.isOn else {
                sections.append(SettingsSection(footer: "开启读取后搜索并选择自己的嘉佰达保护板。", [
                    .action("开启读取并查找设备", icon: ("antenna.radiowaves.left.and.right", .systemBlue)) { [unowned self] in
                        self.bmsEnabledSwitch.setOn(true, animated: false)
                        self.bmsSettingsChanged()
                    }
                ]))
                return sections
            }
            sections.append(SettingsSection(footer: "选定后会记住并自动重连。连接不上时，先断开其他 BMS App。", [
                .action("扫描附近 BMS", icon: ("antenna.radiowaves.left.and.right", .systemBlue)) { [unowned self] in self.bmsClient.scan() },
                .action("忘记当前 BMS", destructive: true) { [unowned self] in
                    self.bmsClient.forget()
                    self.reloadVisibleSettings()
                }
            ]))
            let devices = self.bmsClient.devices.map { device in
                var row = SettingsRow.action(device.name, detail: { "\(device.rssi) dBm" }) { [unowned self] in
                    self.bmsClient.select(device.id)
                }
                row.checked = { [weak self] in self?.bmsClient.selectedID == device.id }
                return row
            }
            sections.append(SettingsSection("附近设备", footer: "仅支持嘉佰达 JBD 的 FF00/FF01/FF02 实时通道。扫描到 FF00 不代表协议兼容，收到有效 JBD 数据后才确认连接。",
                devices.isEmpty ? [.info("暂无设备", "点击上方扫描")] : devices))
            return sections
        }
    }

    /// 打开抓包界面。抓包期间停掉常规 BMS 读取，避免两个连接抢同一个板子。
    private func openSniffer() {
        let wasEnabled = bmsEnabledSwitch.isOn
        if wasEnabled { bmsClient.stop() }
        let sniffer = BMSSnifferViewController()
        sniffer.onFinish = { [weak self] in
            guard let self, wasEnabled else { return }
            self.bmsClient.start()
            self.refreshBMS()
        }
        let navigation = UINavigationController(rootViewController: sniffer)
        let presenter: UIViewController? = rootPage?.navigationController ?? rootPage
        presenter?.present(navigation, animated: true)
        reloadVisibleSettings()
    }

    private func mosPage() -> SettingsPageController {
        page("停放断电") { [unowned self] in
            [SettingsSection("当前状态", footer: "只有在电流接近 0（电池静止、未充未放）时才允许发送 MOS 命令。", [
                .info("实时电流", String(format: "%+.2f A", self.bmsClient.freshReading?.current ?? 0)),
                .info("是否静止", self.isPackIdle ? "是" : "否，请先停稳")
            ]),
            SettingsSection("MOS 控制", footer: "该命令沿用 JBD 标准 0xE1 写帧；这块固件是否接受尚未验证。发送后 1.5 秒会重新读一次数据：仪表无输出即已断电，仍有输出说明板子拒绝。断电后只能在本页重新点「开启放电」恢复。", [
                .action("关闭放电（停放断电）", icon: ("power", .systemRed), destructive: true) { [unowned self] in
                    self.confirmMOS(false)
                },
                .action("开启放电（恢复供电）", icon: ("bolt.fill", .systemGreen)) { [unowned self] in
                    self.confirmMOS(true)
                }
            ])]
        }
    }

    private func bmsCardPage() -> SettingsPageController {
        bmsCardPreview.update(reading: bmsClient.freshReading, configuration: bmsCardConfiguration,
                             aspectRatio: aspectRatio)
        return page("BMS 卡片显示") { [unowned self] in
            var sections = [SettingsSection("布局", footer: "「长条」是一整行横向文字；「面板」是加高的电池面板：上面电量条（中间显示百分比），下面一行数据。修改后立即同步并自动保存。", [
                .control("样式", self.bmsLayoutMenu),
                .control("面板宽度", self.bmsPanelWidthMenu),
                .control("字号", self.bmsCardSize),
                .control("显示位置", self.bmsPosition),
                .control("锁定位置", self.bmsLockSwitch),
                .control("背景透明度", self.opacityControlRow()),
                .action("文字颜色", icon: ("paintpalette", .systemPink), detail: { [unowned self] in
                    "#" + self.bmsCardConfiguration.textColorHex
                }) { [unowned self] in self.openTextColorPicker() },
                .page("字段顺序", icon: ("arrow.up.arrow.down", .systemBlue)) { [unowned self] in
                    BMSCardOrderViewController(fields: self.bmsCardConfiguration.fields) { [weak self] field, destination in
                        guard let self else { return }
                        self.bmsCardConfiguration.move(field, to: destination)
                        self.saveBMSCardConfiguration()
                    }
                }
            ])]
            sections.append(SettingsSection("面板样式", footer: "「电量条」是填充色，「条底」是未充部分，「数据颜色」作用于百分比和下面那行数据。充电流光点只在保护板上报充电电流超过 0.2A 时出现，也可以手动强制播放。", [
                .action("电量条颜色", icon: ("rectangle.fill", .systemGreen), detail: { [unowned self] in
                    "#" + self.bmsCardConfiguration.barColorHex
                }) { [unowned self] in self.openColorPicker(.bar) },
                .action("条底颜色", icon: ("rectangle", .systemGray), detail: { [unowned self] in
                    "#" + self.bmsCardConfiguration.barTrackColorHex
                }) { [unowned self] in self.openColorPicker(.track) },
                .action("数据颜色", icon: ("textformat", .systemBlue), detail: { [unowned self] in
                    "#" + self.bmsCardConfiguration.dataColorHex
                }) { [unowned self] in self.openColorPicker(.data) },
                .control("充电流光点", self.bmsChargingSwitch),
                .control("强制播放", self.bmsForceChargingSwitch),
                .action("选择壁纸", icon: ("photo.on.rectangle", .systemPurple), detail: { [unowned self] in
                    self.bmsCardConfiguration.wallpaperEnabled ? "已启用" : "未选择"
                }) { [unowned self] in self.chooseWallpaper() },
                .action("清除壁纸", icon: ("trash", .systemRed), destructive: true) { [unowned self] in
                    self.clearWallpaper()
                }
            ]))
            sections.append(SettingsSection("布局预览", footer: "在下面的预览里直接按住卡片拖动即可自由摆放，松手自动保存；打开「锁定位置」后拖动失效。背景为布局示意，没有实时读数时使用示例数据。", [
                .note(self.bmsCardPreviewStatus), .view(self.bmsCardPreview)
            ]))
            sections.append(SettingsSection("快捷布局", [
                .action("精简：电量、总压、压差", icon: ("minus.circle", .systemBlue)) { [unowned self] in
                    self.applyBMSCardPreset(BMSCardConfiguration.compactFields)
                },
                .action("常用：显示全部六项", icon: ("square.grid.2x2", .systemBlue)) { [unowned self] in
                    self.applyBMSCardPreset(BMSCardConfiguration.Field.allCases)
                }
            ]))
            let fields = BMSCardConfiguration.Field.allCases.compactMap { field -> SettingsRow? in
                guard let control = self.bmsFieldSwitches[field] else { return nil }
                return .control(field.title, control)
            }
            sections.append(SettingsSection("显示内容", footer: "至少保留一项。单体压差以 mV 显示；未知读数显示 --，BMS 告警会保留提示。", fields))
            return sections
        }
    }


}

extension JBDBMSController: UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    func imagePickerController(_ picker: UIImagePickerController,
                               didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey: Any]) {
        picker.dismiss(animated: true)
        wallpaperPicker = nil
        guard let image = (info[.editedImage] as? UIImage ?? info[.originalImage] as? UIImage) else { return }
        // Keep the bitmap small: the panel is only 640 px wide on the video.
        let target: CGFloat = 900
        let scale = min(1, target / max(image.size.width, image.size.height))
        let resized = UIGraphicsImageRenderer(size: CGSize(width: image.size.width * scale,
                                                           height: image.size.height * scale))
            .image { _ in image.draw(in: CGRect(origin: .zero,
                                                size: CGSize(width: image.size.width * scale,
                                                             height: image.size.height * scale))) }
        BMSWallpaperStore.save(resized)
        bmsCardConfiguration.wallpaperEnabled = true
        saveBMSCardConfiguration()
    }

    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        picker.dismiss(animated: true)
        wallpaperPicker = nil
    }
}
