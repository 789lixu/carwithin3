import UIKit

/// Stores the panel wallpaper chosen from the photo library. The bitmap lives in
/// the app's Documents folder so the overlay can redraw it without the picker.
enum BMSWallpaperStore {
    static let fileName = "bms-panel-wallpaper.jpg"
    private static var cache: UIImage?

    static var url: URL {
        FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
            .appendingPathComponent(fileName)
    }

    static var isAvailable: Bool { FileManager.default.fileExists(atPath: url.path) }

    static func save(_ image: UIImage) {
        guard let data = image.jpegData(compressionQuality: 0.72) ?? image.pngData() else { return }
        cache = nil
        try? data.write(to: url, options: .atomic)
    }

    static func load() -> UIImage? {
        if let cache { return cache }
        guard let image = UIImage(contentsOfFile: url.path) else { return nil }
        cache = image
        return image
    }

    static func clear() {
        cache = nil
        try? FileManager.default.removeItem(at: url)
    }
}

/// Draws the right-side battery column: a slim SOC bar at the very top, the
/// middle left empty for the vehicle's own P card, then pack metrics and a
/// 3-column grid of every cell voltage underneath.
///
/// The canvas is drawn portrait because it is pinned to the right edge of the
/// video at full height, not floated as a card.
struct BMSPanelRenderer {
    /// Column canvas: 424 wide, 960 tall; the compositor stretches it to the
    /// exact right-edge strip of the video, so a small mismatch costs nothing.
    static let canvasWidth: CGFloat = 424
    static let canvasHeight: CGFloat = 960
    static let aspect: CGFloat = canvasHeight / canvasWidth

    static func render(_ reading: BMSReading?, configuration: BMSCardConfiguration, phase: Double) -> CGImage? {
        let size = CGSize(width: canvasWidth, height: canvasHeight)
        let format = UIGraphicsImageRendererFormat()
        format.scale = 1
        let opacity = CGFloat(min(1, max(0, configuration.backgroundOpacity)))
        let dataColor = BMSThemeColor.color(hex: configuration.dataColorHex)
        let barColor = BMSThemeColor.color(hex: configuration.barColorHex)
        let trackColor = BMSThemeColor.color(hex: configuration.barTrackColorHex)
        return UIGraphicsImageRenderer(size: size, format: format).image { context in
            let cg = context.cgContext
            let panel = CGRect(origin: .zero, size: size)

            // Background: photo wallpaper when enabled, otherwise a dark plate.
            // The column is flush with the video edge, so it is never rounded.
            cg.saveGState()
            cg.clip(to: panel)
            if configuration.wallpaperEnabled, let wallpaper = BMSWallpaperStore.load() {
                let source = wallpaper.size
                if source.width > 0, source.height > 0 {
                    let scale = max(panel.width / source.width, panel.height / source.height)
                    let drawSize = CGSize(width: source.width * scale, height: source.height * scale)
                    wallpaper.draw(in: CGRect(x: (panel.width - drawSize.width) / 2,
                                              y: (panel.height - drawSize.height) / 2,
                                              width: drawSize.width, height: drawSize.height))
                }
                UIColor.black.withAlphaComponent(0.20 + 0.55 * opacity).setFill()
                UIRectFill(panel)
            } else {
                UIColor.black.withAlphaComponent(opacity).setFill()
                UIRectFill(panel)
            }
            cg.restoreGState()

            // Hairline on the left so the column reads as its own strip.
            dataColor.withAlphaComponent(0.28).setFill()
            UIRectFill(CGRect(x: 0, y: 0, width: 1.5, height: panel.height))

            guard let reading else {
                drawText("等待电池数据", in: CGRect(x: 12, y: panel.height * 0.55, width: panel.width - 24, height: 60),
                         font: UIFont.monospacedDigitSystemFont(ofSize: 24, weight: .medium),
                         color: dataColor, alignment: .center)
                return
            }

            // Slim SOC bar, kept above the vehicle's P card (top ~7% of the strip).
            let bar = CGRect(x: 10, y: 10, width: panel.width - 20, height: 56)
            let radius: CGFloat = 22
            trackColor.setFill()
            UIBezierPath(roundedRect: bar, cornerRadius: radius).fill()
            let soc = CGFloat(min(100, max(0, reading.stateOfCharge)))
            let fillWidth = max(0, bar.width * soc / 100)
            if fillWidth > 0 {
                barColor.setFill()
                UIBezierPath(roundedRect: CGRect(x: bar.minX, y: bar.minY, width: fillWidth, height: bar.height),
                             cornerRadius: radius).fill()
            }

            // Charging dot travelling left to right, repeated.
            if configuration.shouldAnimateCharging(reading) {
                let travel = max(1, bar.width - 24)
                let x = bar.minX + 12 + travel * CGFloat(min(1, max(0, phase)))
                let dot = CGRect(x: x - 7, y: bar.midY - 7, width: 14, height: 14)
                UIColor.white.withAlphaComponent(0.10).setFill()
                UIBezierPath(roundedRect: dot.insetBy(dx: -4, dy: -4), cornerRadius: 11).fill()
                UIColor.white.withAlphaComponent(0.9).setFill()
                UIBezierPath(roundedRect: dot, cornerRadius: 7).fill()
            }

            let percent = "\(reading.stateOfCharge)%"
            drawText(percent, in: CGRect(x: bar.minX + 10, y: bar.minY + 12, width: bar.width - 20, height: 34),
                     font: UIFont.monospacedDigitSystemFont(ofSize: 27, weight: .bold),
                     color: .white, alignment: .right)

            // The band from y≈70 to y≈506 belongs to the vehicle's P card, so it
            // stays empty on purpose.

            let cells = reading.cells.compactMap { $0 }
            let deltaText = reading.cellDelta.map { String(format: "%.0fmV", ($0 * 1000).rounded()) } ?? "--mV"
            let temperatureText = reading.maximumTemperature.map { String(format: "%.0f°C", $0) } ?? "--°C"
            let alarmColor: UIColor = reading.hasAlarm ? .systemOrange : dataColor

            // Metric rows.
            drawMetric("压差", deltaText, y: 512, color: alarmColor, value: dataColor)
            drawMetric("温度", temperatureText, y: 512, color: dataColor, value: dataColor, rightHalf: true)
            drawMetric("电流", String(format: "%+.1fA", reading.current), y: 552,
                       color: reading.hasAlarm ? .systemOrange : dataColor, value: dataColor)
            drawMetric("功率", "\(reading.power)W", y: 552, color: dataColor, value: dataColor, rightHalf: true)

            dataColor.withAlphaComponent(0.35).setFill()
            UIRectFill(CGRect(x: 12, y: 594, width: panel.width - 24, height: 1))

            // Every cell voltage, three columns wide, highest and lowest tinted.
            guard !cells.isEmpty else {
                drawText("单体电压：--", in: CGRect(x: 12, y: 606, width: panel.width - 24, height: 40),
                         font: UIFont.monospacedDigitSystemFont(ofSize: 22, weight: .medium),
                         color: dataColor.withAlphaComponent(0.7), alignment: .left)
                return
            }
            let high = cells.max() ?? 0
            let low = cells.min() ?? 0
            let columns = 3
            let columnWidth = (panel.width - 20) / CGFloat(columns)
            let rowHeight: CGFloat = 42
            let top: CGFloat = 606
            for (index, voltage) in cells.enumerated() {
                let column = index % columns
                let row = index / columns
                let x = 10 + CGFloat(column) * columnWidth
                let y = top + CGFloat(row) * rowHeight
                guard y + rowHeight <= panel.height - 4 else { break }
                let indexText = String(format: "%02d", index + 1)
                drawText(indexText, in: CGRect(x: x, y: y + 9, width: 20, height: 18),
                         font: UIFont.monospacedDigitSystemFont(ofSize: 13, weight: .regular),
                         color: dataColor.withAlphaComponent(0.55), alignment: .left)
                let color: UIColor
                if voltage >= high - 0.0001 { color = .systemRed }
                else if voltage <= low + 0.0001 { color = .systemGreen }
                else { color = dataColor }
                drawText(String(format: "%.3f", voltage),
                         in: CGRect(x: x + 20, y: y + 2, width: columnWidth - 22, height: 30),
                         font: UIFont.monospacedDigitSystemFont(ofSize: 22, weight: .bold),
                         color: color, alignment: .left)
            }
        }.cgImage
    }

    private static func drawMetric(_ title: String, _ value: String, y: CGFloat, color: UIColor,
                                   value valueColor: UIColor, rightHalf: Bool = false) {
        let width = (canvasWidth - 20) / 2
        let x: CGFloat = rightHalf ? 10 + width : 10
        drawText(title, in: CGRect(x: x, y: y + 6, width: 44, height: 26),
                 font: UIFont.systemFont(ofSize: 17, weight: .regular),
                 color: color.withAlphaComponent(0.6), alignment: .left)
        drawText(value, in: CGRect(x: x + 40, y: y, width: width - 42, height: 34),
                 font: UIFont.monospacedDigitSystemFont(ofSize: 25, weight: .semibold),
                 color: valueColor, alignment: .left)
    }

    private static func drawText(_ text: String, in rect: CGRect, font: UIFont,
                                 color: UIColor, alignment: NSTextAlignment) {
        let paragraph = NSMutableParagraphStyle()
        paragraph.alignment = alignment
        paragraph.lineBreakMode = .byTruncatingTail
        (text as NSString).draw(in: rect, withAttributes: [
            .font: font, .foregroundColor: color, .paragraphStyle: paragraph
        ])
    }
}
